;; theme file, written Thu Jan 10 20:57:29 2002
;; created by sawfish-themer -- DO NOT EDIT!

(require 'make-theme)

(let
    ((patterns-alist
      '(("b_icon"
         (inactive
          "b_icon_n.png")
         (focused
          "b_icon_h.png")
         (clicked
          "b_icon_c.png"))
        ("b_kill"
         (inactive
          "b_kill_n.png")
         (focused
          "b_kill_h.png")
         (clicked
          "b_kill_c.png"))
        ("b_max"
         (inactive
          "b_max_n.png")
         (focused
          "b_max_h.png")
         (clicked
          "b_max_c.png"))
        ("r_bl"
         (inactive
          "r_bl_n.png")
         (focused
          "r_bl_h.png"))
        ("r_br"
         (inactive
          "r_br_n.png")
         (focused
          "r_br_h.png"))
        ("r_horz"
         (inactive
          "r_horz_n.png"
          (border
           1
           2
           0
           0))
         (focused
          "r_horz_h.png"
          (border
           1
           2
           0
           0)))
        ("tbh"
         (inactive
          "tbh_n.png"
          (border
           2
           2
           2
           2))
         (focused
          "tbh_h.png"
          (border
           2
           2
           2
           2))
         (clicked
          "tbh_c.png"
          (border
           2
           2
           2
           2)))
        ("r_tl"
         (inactive
          "r_tl_n.png")
         (focused
          "r_tl_h.png"))
        ("r_tr"
         (inactive
          "r_tr_n.png")
         (focused
          "r_tr_h.png"))
        ("r_vert"
         (inactive
          "r_vert_n.png"
          (border
           0
           0
           1
           2))
         (focused
          "r_vert_h.png"
          (border
           0
           0
           1
           2)))
        ("shaded_base"
         (inactive
          "shaded_base_n.png")
         (focused
          "shaded_base_h.png"))
        ("shaded_tbl"
         (inactive
          "shaded_tbl_n.png")
         (focused
          "shaded_tbl_h.png"))
        ("shaded_tbr"
         (inactive
          "shaded_tbr_n.png")
         (focused
          "shaded_tbr_h.png"))
        ("shaded_top"
         (inactive
          "shaded_top_n.png")
         (focused
          "shaded_top_h.png"))))

     (frames-alist
      '(("default"
         ((top-edge . -19)
          (right-edge . 0)
          (background . "b_max")
          (class . maximize-button))
         ((right-edge . 20)
          (background . "b_icon")
          (top-edge . -19)
          (class . iconify-button))
         ((left-edge . 0)
          (top-edge . -19)
          (background . "b_kill")
          (class . close-button))
         ((font . "-*-helvetica-bold-o-normal-*-12-*-*-*-*-*-iso8859-1")
          (left-edge . 20)
          (right-edge . 40)
          (top-edge . -19)
          (y-justify . center)
          (x-justify . 8)
          (text . window-name)
          (background . "tbh")
          (class . title))
         ((top-edge . -25)
          (left-edge . -6)
          (background . "r_tl")
          (class . top-left-corner))
         ((right-edge . -6)
          (background . "r_tr")
          (top-edge . -25)
          (class . top-right-corner))
         ((left-edge . -6)
          (background . "r_bl")
          (bottom-edge . -6)
          (class . bottom-left-corner))
         ((background . "r_br")
          (bottom-edge . -6)
          (right-edge . -6)
          (class . bottom-right-corner))
         ((left-edge . 20)
          (right-edge . 20)
          (top-edge . -25)
          (background . "r_horz")
          (class . top-border))
         ((background . "r_horz")
          (bottom-edge . -6)
          (left-edge . 20)
          (right-edge . 20)
          (class . bottom-border))
         ((bottom-edge . 19)
          (top-edge . 0)
          (left-edge . -6)
          (background . "r_vert")
          (class . left-border))
         ((right-edge . -6)
          (top-edge . 0)
          (bottom-edge . 19)
          (background . "r_vert")
          (class . right-border)))
        ("shaded"
         ((left-edge . 20)
          (right-edge . 40)
          (font . "-*-helvetica-bold-o-normal-*-12-*-*-*-*-*-iso8859-1")
          (background . "tbh")
          (y-justify . center)
          (x-justify . 8)
          (text . window-name)
          (top-edge . -19)
          (class . title))
         ((left-edge . 0)
          (right-edge . 0)
          (below-client . t)
          (class . bottom-border)
          (background . "shaded_base"))
         ((class . maximize-button)
          (background . "b_max")
          (top-edge . -19)
          (right-edge . 0))
         ((class . iconify-button)
          (background . "b_icon")
          (right-edge . 20)
          (top-edge . -19))
         ((background . "b_kill")
          (class . close-button)
          (left-edge . 0)
          (top-edge . -19))
         ((right-edge . -6)
          (top-edge . -25)
          (background . "shaded_tbr")
          (class . right-border))
         ((right-edge . 0)
          (left-edge . 0)
          (background . "shaded_top")
          (top-edge . -25)
          (class . top-border))
         ((background . "shaded_tbl")
          (class . left-border)
          (top-edge . -25)
          (left-edge . -6)))))

     (mapping-alist
      '((default . "default")
        (shaded . "shaded")))

     (theme-name 'ifish))

  (add-frame-style
   theme-name (make-theme patterns-alist frames-alist mapping-alist))
  (when (boundp 'mark-frame-style-editable)
    (mark-frame-style-editable theme-name)))
