Panther GTK2/Metacity/Icon
By GrandMasta

Getsome

extract and drop 'Panther' folder into /home/{$USER}/.themes

Then apply theme from Gnome Menu As Normal.


Thanks to Susumu for use of the nautilus toolbar Icons.