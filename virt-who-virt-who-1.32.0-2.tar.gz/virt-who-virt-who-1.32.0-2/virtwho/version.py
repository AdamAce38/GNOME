# The values in this file are populated by setup.py build
__version__ = 'RPM_VERSION'
