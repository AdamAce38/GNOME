from __future__ import print_function

# Default interval for sending list of UUIDs
DefaultInterval = 3600  # One per hour
MinimumSendInterval = 60  # One minute
MinimumJobPollInterval = 15

SAT5 = "satellite"
SAT6 = "sam"
