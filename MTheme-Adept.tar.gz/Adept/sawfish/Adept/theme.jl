;; theme file, written Wed Jul  5 14:51:03 2000
;; created by sawfish-themer -- DO NOT EDIT!

(require 'make-theme)

(let
    ((patterns-alist
      '(("border_top"
         (inactive
          "topgrey.png"))
        ("resize_right-focused"
         (inactive
          "resize_right.png")
         (focused
          "resize_right-focused.png"))
        ("resize_middle"
         (inactive
          "resize_middle.png")
         (focused
          "resize_middle-focused.png"))
        ("resize_left-focused"
         (inactive
          "resize_left.png")
         (focused
          "resize_left-focused.png"))
        ("close"
         (inactive
          "close.png")
         (focused
          "close.png")
         (clicked
          "close-clicked.png"))
        ("maximize"
         (inactive
          "maximize.png")
         (focused
          "maximize.png")
         (clicked
          "maximize-clicked.png"))
        ("titlecolors"
         (inactive . "#bffdbffdbffd")
         (focused . "#ffffffffffff"))
        ("title-back"
         (inactive
          "titlebar.png")
         (focused
          "titlebar-focused.png"))
        ("iconify"
         (inactive
          "iconify.png")
         (focused
          "iconify.png")
         (clicked
          "iconify-clicked.png"))
        ("border_right"
         (inactive
          "border_right.png"))
        ("border_left"
         (inactive
          "border_left.png"))
        ("outline"
         (inactive
          "outline.png"))))

     (frames-alist
      '(("normal"
         ((left-edge . -1)
          (right-edge . -1)
          (top-edge . -21)
          (background . "outline")
          (class . top-border))
         ((top-edge . -2)
          (left-edge . -3)
          (bottom-edge . 0)
          (background . "border_left")
          (class . left-border))
         ((top-edge . -2)
          (right-edge . -3)
          (background . "border_right")
          (bottom-edge . 0)
          (class . right-border))
         ((cursor . left_ptr)
          (left-edge . -3)
          (top-edge . -21)
          (background . "iconify")
          (class . iconify-button))
         ((cursor . left_ptr)
          (left-edge . 15)
          (right-edge . 31)
          (font . "-b&h-lucida-medium-r-normal-*-*-100-*-*-p-*-iso8859-1")
          (x-justify . center)
          (background . "title-back")
          (foreground . "titlecolors")
          (top-edge . -21)
          (class . title)
          (text . window-name)
          (y-justify . 2))
         ((cursor . left_ptr)
          (right-edge . 14)
          (top-edge . -21)
          (background . "maximize")
          (class . maximize-button)
          (x-justify . center)
          (y-justify . center))
         ((cursor . left_ptr)
          (right-edge . -3)
          (top-edge . -21)
          (background . "close")
          (class . close-button)
          (x-justify . center)
          (y-justify . center))
         ((bottom-edge . -9)
          (left-edge . -3)
          (background . "resize_left-focused")
          (class . bottom-left-corner)
          (x-justify . center)
          (y-justify . center))
         ((left-edge . 21)
          (right-edge . 21)
          (background . "resize_middle")
          (bottom-edge . -9)
          (class . bottom-border)
          (x-justify . center)
          (y-justify . center))
         ((right-edge . -3)
          (bottom-edge . -9)
          (background . "resize_right-focused")
          (class . bottom-right-corner)
          (x-justify . center)
          (y-justify . center))
         ((background . "border_top")
          (top-edge . -2)
          (right-edge . 0)
          (left-edge . 0)
          (class . top-border)))
        ("shaded"
         ((right-edge . -1)
          (left-edge . -1)
          (top-edge . -21)
          (background . "outline")
          (class . top-border))
         ((top-edge . -21)
          (cursor . left_ptr)
          (left-edge . -3)
          (background . "iconify")
          (class . iconify-button))
         ((cursor . left_ptr)
          (left-edge . 15)
          (right-edge . 31)
          (font . "-b&h-lucida-medium-r-normal-*-*-100-*-*-p-*-iso8859-1")
          (x-justify . center)
          (background . "title-back")
          (foreground . "titlecolors")
          (top-edge . -21)
          (class . title)
          (text . window-name)
          (y-justify . 2))
         ((right-edge . 14)
          (cursor . left_ptr)
          (top-edge . -21)
          (background . "maximize")
          (class . maximize-button)
          (x-justify . center)
          (y-justify . center))
         ((cursor . left_ptr)
          (right-edge . -3)
          (top-edge . -21)
          (background . "close")
          (class . close-button)
          (x-justify . center)
          (y-justify . center)))
        ("shaded_withbar"
         ((right-edge . -1)
          (left-edge . -1)
          (top-edge . -21)
          (background . "outline")
          (class . top-border))
         ((top-edge . -21)
          (cursor . left_ptr)
          (left-edge . -3)
          (background . "iconify")
          (class . iconify-button))
         ((cursor . left_ptr)
          (left-edge . 15)
          (right-edge . 31)
          (font . "-b&h-lucida-medium-r-normal-*-*-100-*-*-p-*-iso8859-1")
          (x-justify . center)
          (background . "title-back")
          (foreground . "titlecolors")
          (top-edge . -21)
          (class . title)
          (text . window-name)
          (y-justify . 2))
         ((cursor . left_ptr)
          (right-edge . 14)
          (top-edge . -21)
          (background . "maximize")
          (class . maximize-button)
          (x-justify . center)
          (y-justify . center))
         ((cursor . left_ptr)
          (right-edge . -3)
          (top-edge . -21)
          (background . "close")
          (class . close-button)
          (x-justify . center)
          (y-justify . center))
         ((top-edge . -2)
          (left-edge . -3)
          (background . "resize_left-focused")
          (class . bottom-left-corner)
          (x-justify . center)
          (y-justify . center))
         ((left-edge . 21)
          (top-edge . -2)
          (right-edge . 21)
          (background . "resize_middle")
          (class . bottom-border)
          (x-justify . center)
          (y-justify . center))
         ((right-edge . -3)
          (top-edge . -2)
          (background . "resize_right-focused")
          (class . bottom-right-corner)
          (x-justify . center)
          (y-justify . center)))))

     (mapping-alist
      '((default . "normal")
        (transient . "normal")
        (shaped . "shaded")
        (shaped-transient . "shaded")
        (unframed . "nil")))

     (theme-name 'Adept))

  (add-frame-style
   theme-name (make-theme patterns-alist frames-alist mapping-alist))
  (when (boundp 'mark-frame-style-editable)
    (mark-frame-style-editable theme-name)))
