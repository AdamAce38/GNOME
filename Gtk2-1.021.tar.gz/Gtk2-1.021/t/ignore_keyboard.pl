Gtk2->key_snooper_install (sub { 1; });
1;
