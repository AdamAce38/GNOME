;; theme file, written Sun Feb 25 21:03:05 2001
;; created by sawfish-themer -- DO NOT EDIT!

(require 'make-theme)

(let
    ((patterns-alist
      '(("maximize"
         (inactive
          "max_n.png")
         (focused
          "max_h.png")
         (highlighted
          "max_h.png")
         (clicked
          "max_c.png"))
        ("title"
         (inactive
          "title_n.png"
          (border
           1
           1
           0
           0))
         (focused
          "title_h.png"
          (border
           1
           1
           0
           0))
         (highlighted
          "title_h.png"
          (border
           1
           1
           0
           0))
         (clicked
          "title_c.png"
          (border
           1
           1
           0
           0)))
        ("minimize"
         (inactive
          "iconify_n.png")
         (focused
          "iconify_h.png")
         (highlighted
          "iconify_h.png")
         (clicked
          "iconify_c.png"))
        ("top-right"
         (inactive
          "top_right_resize_n.png")
         (focused
          "top_right_resize_h.png")
         (highlighted
          "top_right_resize_h.png"))
        ("top"
         (inactive
          "resize_top_n.png"
          (border
           1
           1
           0
           0))
         (focused
          "resize_top_h.png"
          (border
           1
           1
           0
           0))
         (highlighted
          "resize_top_h.png"
          (border
           1
           1
           0
           0)))
        ("menu"
         (inactive
          "menu_n.png")
         (focused
          "menu_h.png")
         (highlighted
          "menu_h.png")
         (clicked
          "menu_c.png"))
        ("top-left"
         (inactive
          "top_left_resize_n.png")
         (focused
          "top_left_resize_h.png")
         (highlighted
          "top_left_resize_h.png"))
        ("bottom-right"
         (inactive
          "bottom_right_resize_n.png")
         (focused
          "bottom_right_resize_h.png")
         (highlighted
          "bottom_right_resize_h.png"))
        ("bottom-left"
         (inactive
          "bottom_left_resize_n.png")
         (focused
          "bottom_left_resize_h.png")
         (highlighted
          "bottom_left_resize_h.png"))
        ("left"
         (inactive
          "resize_left_n.png"
          (border
           0
           0
           1
           1))
         (focused
          "resize_left_h.png"
          (border
           0
           0
           1
           1))
         (highlighted
          "resize_left_h.png"
          (border
           0
           0
           1
           1)))
        ("right"
         (inactive
          "resize_right_n.png"
          (border
           0
           0
           1
           1))
         (focused
          "resize_right_h.png"
          (border
           0
           0
           1
           1))
         (highlighted
          "resize_right_h.png"
          (border
           0
           0
           1
           1)))
        ("bottom"
         (inactive
          "resize_bottom_n.png"
          (border
           1
           1
           0
           0))
         (focused
          "resize_bottom_h.png"
          (border
           1
           1
           0
           0))
         (highlighted
          "resize_bottom_h.png"
          (border
           1
           1
           0
           0)))
        ("shaded-right"
         (inactive
          "shaded_right_n.png")
         (focused
          "shaded_right_h.png")
         (highlighted
          "shaded_right_h.png"))
        ("shaded-left"
         (inactive
          "shaded_left_n.png")
         (focused
          "shaded_left_h.png")
         (highlighted
          "shaded_left_h.png"))
        ("fgcolor"
         (inactive . "#000000000000")
         (focused . "#ffffffffffff")
         (highlighted . "#ffffffffffff")
         (clicked . "#ffffffffffff"))
        ("top-left-trans"
         (inactive
          "top_left_trans_n.png")
         (focused
          "top_left_trans_h.png")
         (highlighted
          "top_left_trans_h.png"))
        ("top-right-trans"
         (inactive
          "top_right_trans_n.png")
         (focused
          "top_right_trans_h.png")
         (highlighted
          "top_right_trans_h.png"))
        ("top-trans"
         (inactive
          "trans_top_n.png"
          (border
           1
           1
           0
           0))
         (focused
          "trans_top_h.png"
          (border
           1
           1
           0
           0))
         (highlighted
          "trans_top_h.png"
          (border
           1
           1
           0
           0)))
        ("right-trans"
         (inactive
          "trans_right_n.png"
          (border
           0
           0
           1
           1))
         (focused
          "trans_right_h.png"
          (border
           0
           0
           1
           1))
         (highlighted
          "trans_right_h.png"
          (border
           0
           0
           1
           1)))
        ("left-trans"
         (inactive
          "trans_left_n.png"
          (border
           0
           0
           1
           1))
         (focused
          "trans_left_h.png"
          (border
           0
           0
           1
           1))
         (highlighted
          "trans_left_h.png"
          (border
           0
           0
           1
           1)))
        ("bottom-trans"
         (inactive
          "trans_bottom_n.png"
          (border
           1
           1
           0
           0))
         (focused
          "trans_bottom_h.png"
          (border
           1
           1
           0
           0))
         (highlighted
          "trans_bottom_h.png"
          (border
           1
           1
           0
           0)))
        ("bottom-left-trans"
         (inactive
          "bottom_left_trans_n.png")
         (focused
          "bottom_left_trans_h.png")
         (highlighted
          "bottom_left_trans_h.png"))
        ("bottom-right-trans"
         (inactive
          "bottom_right_trans_n.png")
         (focused
          "bottom_right_trans_h.png")
         (highlighted
          "bottom_right_trans_h.png"))
        ("shaded-right-trans"
         (inactive
          "shaded_right_trans_n.png")
         (focused
          "shaded_right_trans_h.png")
         (highlighted
          "shaded_right_trans_h.png"))
        ("shaded-left-trans"
         (inactive
          "shaded_left_trans_n.png")
         (focused
          "shaded_left_trans_h.png")
         (highlighted
          "shaded_left_trans_h.png"))))

     (frames-alist
      '(("normal"
         ((right-edge . 0)
          (top-edge . -18)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 18)
          (top-edge . -18)
          (background . "minimize")
          (class . iconify-button))
         ((top-edge . -24)
          (right-edge . -6)
          (background . "top-right")
          (class . top-right-corner))
         ((right-edge . 36)
          (left-edge . 18)
          (top-edge . -18)
          (foreground . "fgcolor")
          (y-justify . center)
          (x-justify . center)
          (text . window-name)
          (background . "title")
          (class . title))
         ((left-edge . 18)
          (right-edge . 18)
          (top-edge . -24)
          (background . "top")
          (class . top-border))
         ((top-edge . -18)
          (left-edge . 0)
          (background . "menu")
          (class . menu-button))
         ((top-edge . -24)
          (left-edge . -6)
          (background . "top-left")
          (class . top-left-corner))
         ((bottom-edge . -6)
          (right-edge . -6)
          (background . "bottom-right")
          (class . bottom-right-corner))
         ((bottom-edge . -6)
          (left-edge . -6)
          (background . "bottom-left")
          (class . bottom-left-corner))
         ((bottom-edge . 18)
          (top-edge . 0)
          (left-edge . -6)
          (background . "left")
          (class . left-border))
         ((right-edge . -6)
          (top-edge . 0)
          (bottom-edge . 18)
          (background . "right")
          (class . right-border))
         ((left-edge . 18)
          (right-edge . 18)
          (bottom-edge . -6)
          (background . "bottom")
          (class . bottom-border)))
        ("shaped"
         ((right-edge . 0)
          (top-edge . -18)
          (background . "maximize")
          (class . maximize-button))
         ((right-edge . 18)
          (top-edge . -18)
          (background . "minimize")
          (class . iconify-button))
         ((right-edge . 36)
          (top-edge . -18)
          (foreground . "fgcolor")
          (left-edge . 18)
          (y-justify . center)
          (x-justify . center)
          (text . window-name)
          (background . "title")
          (class . title))
         ((top-edge . -24)
          (right-edge . 18)
          (left-edge . 18)
          (background . "top")
          (class . top-border))
         ((left-edge . 0)
          (top-edge . -18)
          (background . "menu")
          (class . menu-button))
         ((right-edge . -6)
          (top-edge . -24)
          (background . "shaded-right")
          (class . right-border))
         ((top-edge . -24)
          (left-edge . -6)
          (background . "shaded-left")
          (class . left-border))
         ((left-edge . 18)
          (top-edge . 0)
          (right-edge . 18)
          (background . "bottom")
          (class . bottom-border)))
        ("nil")
        ("transient"
         ((right-edge . 0)
          (left-edge . 18)
          (top-edge . -18)
          (foreground . "fgcolor")
          (y-justify . center)
          (x-justify . center)
          (text . window-name)
          (background . "title")
          (class . title))
         ((left-edge . 0)
          (top-edge . -18)
          (background . "menu")
          (class . menu-button))
         ((top-edge . -23)
          (right-edge . 18)
          (left-edge . 18)
          (background . "top-trans")
          (class . top-border))
         ((left-edge . -5)
          (background . "left-trans")
          (bottom-edge . 18)
          (top-edge . 0)
          (class . left-border))
         ((bottom-edge . 18)
          (right-edge . -5)
          (top-edge . 0)
          (background . "right-trans")
          (class . right-border))
         ((bottom-edge . -5)
          (right-edge . 18)
          (left-edge . 18)
          (background . "bottom-trans")
          (class . bottom-border))
         ((top-edge . -23)
          (left-edge . -5)
          (background . "top-left-trans")
          (class . top-left-corner))
         ((right-edge . -5)
          (top-edge . -23)
          (background . "top-right-trans")
          (class . top-right-corner))
         ((bottom-edge . -5)
          (left-edge . -5)
          (background . "bottom-left-trans")
          (class . bottom-left-corner))
         ((background . "bottom-right-trans")
          (bottom-edge . -5)
          (right-edge . -5)
          (class . bottom-right-corner)))
        ("shaped transient"
         ((top-edge . -18)
          (left-edge . 18)
          (right-edge . 0)
          (foreground . "fgcolor")
          (y-justify . center)
          (x-justify . center)
          (text . window-name)
          (background . "title")
          (class . title))
         ((left-edge . 0)
          (top-edge . -18)
          (background . "menu")
          (class . menu-button))
         ((background . "top-trans")
          (top-edge . -23)
          (right-edge . 18)
          (left-edge . 18)
          (class . top-border))
         ((background . "shaded-left-trans")
          (left-edge . -5)
          (top-edge . -23)
          (class . left-border))
         ((background . "shaded-right-trans")
          (right-edge . -5)
          (top-edge . -23)
          (class . right-border))
         ((background . "bottom-trans")
          (left-edge . 18)
          (right-edge . 18)
          (top-edge . 0)
          (class . bottom-border)))))

     (mapping-alist
      '((default . "normal")
        (shaped . "shaped")
        (transient . "transient")
        (unframed . "nil")
        (shaped-transient . "shaped transient")))

     (theme-name 'Mwm-OSF))

  (add-frame-style
   theme-name (make-theme patterns-alist frames-alist mapping-alist))
  (when (boundp 'mark-frame-style-editable)
    (mark-frame-style-editable theme-name)))
