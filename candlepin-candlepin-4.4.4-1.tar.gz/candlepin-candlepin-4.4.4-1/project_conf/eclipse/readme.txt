This directory contains the files to configure eclipse's
style.


candlepin.importorder - specifies the order imports should be specified
 - org.candlepin
 - com
 - org
 - java
 - javax

code_formatter_candlepin.xml
 - specifies a code format that will work with Candlepin's checkstyle rules.

code_templates_code.xml
 - basic code templates for generated code, specifies the Red Hat copyright
   header.

code_templates_comments.xml
 - basic code templates for generated comments.

