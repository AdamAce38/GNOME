#ifndef GUILE_COMPAT_H
#define GUILE_COMPAT_H

#include <libguile.h>

void scm_done_malloc (long size);
SCM scm_internal_cwdr SCM_P ((scm_catch_body_t body,
			      void *body_data,
			      scm_catch_handler_t handler,
			      void *handler_data,
			      SCM_STACKITEM *stack_start));

#endif
