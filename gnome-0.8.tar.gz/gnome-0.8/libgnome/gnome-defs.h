#ifdef __cplusplus 
#define BEGIN_GNOME_DECLS extern "C" {
#define END_GNOME_DECLS }
#else
#define BEGIN_GNOME_DECLS
#define END_GNOME_DECLS
#endif
