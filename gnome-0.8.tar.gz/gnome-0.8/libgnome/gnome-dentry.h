#ifndef __GNOME_DENTRY_H__
#define __GNOME_DENTRY_H__

BEGIN_GNOME_DECLS

struct gnome_desktop_entry {
	char *exec;
	char *icon_base;
	char *docpath;
	char *info;
	int  terminal;
	char *type;
	char *location;
	
	/* These are computed from icon_base */
	char *small_icon;
	char *transparent_icon;
};

struct gnome_desktop_entry *gnome_desktop_entry_load (char *file);
void   gnome_desktop_entry_free   (struct gnome_desktop_entry *item);
void   gnome_desktop_entry_launch (struct gnome_desktop_entry *item);

int gnome_is_program_in_path (char *progname);

END_GNOME_DECLS

#endif
