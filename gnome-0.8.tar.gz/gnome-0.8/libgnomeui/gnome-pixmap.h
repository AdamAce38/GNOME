
#ifndef __GNOME_PIXMAP_H__
#define __GNOME_PIXMAP_H__

BEGIN_GNOME_DECLS

GtkWidget *gnome_create_pixmap_widget (GtkWidget *window, GtkWidget *holder, char *file);

END_GNOME_DECLS

#endif /* __GNOME_PIXMAP_H__ */
