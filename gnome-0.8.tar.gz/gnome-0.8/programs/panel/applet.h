#ifndef APPLET_H
#define APPLET_H

#include "gnome.h"
#include "panel.h"

BEGIN_GNOME_DECLS


typedef struct {
	void *dl_handle;
	char *filename;
} AppletFile;

typedef char * (*AppletQueryFunc) (void);
typedef void (*AppletInitFunc) (PanelCallback callback, Panel *panel, char *params, int xpos, int ypos);


extern GHashTable *applet_files_ht;


void applets_init(void);
void applets_destroy(void);
void applets_init_applet(char *name, char *params, int xpos, int ypos);


END_GNOME_DECLS

#endif
