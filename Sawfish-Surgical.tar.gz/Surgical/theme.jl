;; theme file, written Sat Mar 16 21:03:11 2002
;; created by sawfish-themer -- DO NOT EDIT!

(require 'make-theme)

(let
    ((patterns-alist
      '(("topborder"
         (inactive
          "topborder_focused.png")
         (focused
          "topborder_focused.png"))
        ("leftborder"
         (inactive
          "leftborder_focused.png")
         (focused
          "leftborder_focused.png"))
        ("rightborder"
         (inactive
          "rightborder.png")
         (focused
          "rightborder_focused.png"))
        ("bottomborder"
         (inactive
          "bottomborder.png")
         (focused
          "bottomborder_focused.png"))
        ("bottomrightcorner"
         (inactive
          "brcorner.png")
         (focused
          "brcorner_focused.png"))
        ("bottomleftcorner"
         (inactive
          "blcorner.png")
         (focused
          "blcorner_focused.png"))
        ("titlebarbkg"
         (inactive
          "titlebarbkg.png")
         (focused
          "titlebarbkg_focused.png"))
        ("topleftcorner"
         (inactive
          "tlcorner.png")
         (focused
          "tlcorner_focused.png"))
        ("toprightcorner"
         (inactive
          "trcorner.png")
         (focused
          "trcorner_focused.png"))
        ("titlecolors"
         (inactive . "#7fff7fff7fff")
         (focused . "#333333333333"))
        ("bottomborder_shade"
         (inactive
          "bottomborder_shade.png")
         (focused
          "bottomborder_focused_shade.png"))
        ("bottomrightcorner_shade"
         (inactive
          "brcorner_shade.png")
         (focused
          "brcorner_focused_shade.png"))
        ("bottomleftcorder_shade"
         (inactive
          "blcorner_shade.png")
         (focused
          "blcorner_focused_shade.png"))
        ("titlebarbkg_shaded"
         (inactive
          "titlebarbkg.png")
         (focused
          "titlebarbkg_shade.png"))
        ("topleftcorner_shade"
         (inactive
          "tlcorner_shade.png")
         (focused
          "tlcorner_focused_shade.png"))
        ("toprightcorner_shade"
         (inactive
          "trcorner_shaded.png")
         (focused
          "trcorner_focused_shaded.png"))
        ("close_button"
         (inactive
          "openbox.png")
         (focused
          "openbox_focus.png")
         (highlighted
          "close_focus.png")
         (inactive-highlighted
          "close.png")
         (clicked
          "close_focus.png")
         (inactive-clicked
          "close.png"))
        ("min_button"
         (inactive
          "openbox.png")
         (focused
          "openbox_focus.png")
         (highlighted
          "min_focus.png")
         (inactive-highlighted
          "min.png")
         (clicked
          "min_focus.png")
         (inactive-clicked
          "min.png"))
        ("max_button"
         (inactive
          "openbox.png")
         (focused
          "openbox_focus.png")
         (highlighted
          "max_focus.png")
         (inactive-highlighted
          "max.png")
         (clicked
          "max_focus.png")
         (inactive-clicked
          "max.png"))))

     (frames-alist
      '(("normal"
         ((top-edge . -19)
          (left-edge . 0)
          (right-edge . 0)
          (background . "topborder")
          (class . top-border))
         ((bottom-edge . 0)
          (top-edge . 0)
          (left-edge . -4)
          (background . "leftborder")
          (class . left-border))
         ((top-edge . 0)
          (bottom-edge . 0)
          (right-edge . -5)
          (background . "rightborder")
          (class . right-border))
         ((left-edge . 0)
          (bottom-edge . -5)
          (right-edge . 0)
          (removable . t)
          (background . "bottomborder")
          (class . bottom-border))
         ((background . "bottomleftcorner")
          (left-edge . -4)
          (bottom-edge . -5)
          (class . bottom-left-corner))
         ((right-edge . -5)
          (bottom-edge . -5)
          (background . "bottomrightcorner")
          (class . bottom-right-corner))
         ((top-edge . -17)
          (font . "-schumacher-clean-medium-r-normal-*-10-*-*-*-c-*-iso646.1991-irv")
          (foreground . "titlecolors")
          (text . window-name)
          (y-justify . 3)
          (x-justify . center)
          (right-edge . 0)
          (left-edge . 0)
          (background . "titlebarbkg")
          (class . title))
         ((top-edge . -19)
          (left-edge . -4)
          (background . "topleftcorner")
          (class . top-left-corner))
         ((background . "toprightcorner")
          (top-edge . -19)
          (right-edge . -5)
          (class . top-right-corner))
         ((left-edge . 1)
          (top-edge . -14)
          (background . "close_button")
          (class . close-button))
         ((right-edge . 1)
          (background . "max_button")
          (top-edge . -14)
          (class . maximize-button))
         ((top-edge . -14)
          (right-edge . 13)
          (background . "min_button")
          (class . iconify-button)))
        ("shaded"
         ((top-edge . -19)
          (left-edge . 0)
          (right-edge . 0)
          (background . "topborder")
          (class . top-border))
         ((background . "bottomborder_shade")
          (right-edge . 0)
          (left-edge . 0)
          (top-edge . 0)
          (removable . t)
          (class . bottom-border))
         ((background . "bottomleftcorder_shade")
          (left-edge . -4)
          (top-edge . 0)
          (class . bottom-left-corner))
         ((background . "bottomrightcorner_shade")
          (right-edge . -5)
          (top-edge . 0)
          (class . bottom-right-corner))
         ((background . "titlebarbkg_shaded")
          (font . "-schumacher-clean-medium-r-normal-*-10-*-*-*-c-*-iso646.1991-irv")
          (top-edge . -17)
          (foreground . "titlecolors")
          (text . window-name)
          (y-justify . 3)
          (x-justify . center)
          (right-edge . 0)
          (left-edge . 0)
          (class . title))
         ((background . "topleftcorner_shade")
          (left-edge . -4)
          (top-edge . -19)
          (class . top-left-corner))
         ((right-edge . -5)
          (background . "toprightcorner_shade")
          (top-edge . -19)
          (class . top-right-corner))
         ((background . "close_button")
          (top-edge . -14)
          (left-edge . 1)
          (class . close-button))
         ((background . "max_button")
          (top-edge . -14)
          (right-edge . 1)
          (class . maximize-button))
         ((background . "min_button")
          (right-edge . 13)
          (top-edge . -14)
          (class . iconify-button)))))

     (mapping-alist
      '((default . "normal")
        (transient . "normal")
        (shaped . "shaded")
        (shaped-transient . "shaded")
        (unframed . "nil")))

     (theme-name 'Surgical))

  (add-frame-style
   theme-name (make-theme patterns-alist frames-alist mapping-alist))
  (when (boundp 'mark-frame-style-editable)
    (mark-frame-style-editable theme-name)))
