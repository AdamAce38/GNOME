/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gnome.event;

import org.gnu.gtk.event.GtkEvent;
import org.gnu.gtk.event.GtkEventType;

/**
 * An event represeting action by a {@link org.gnu.gnome.FontPicker} widget.
 */
public class FontPickerEvent extends GtkEvent {
    public static class Type extends GtkEventType{
	private Type(int id, String name){
	    super(id, name);
	}
	/**
	 */
	public static final Type FONT_SET = new Type(1, "FONT_SET");
    }

	/**
	 * Creates a new FontPickerEvent. This is used internally by java-gnome.
	 * Users only have to deal with listeners.
	 */
	public FontPickerEvent(Object source) {
		super(source, Type.FONT_SET);
	}
}
