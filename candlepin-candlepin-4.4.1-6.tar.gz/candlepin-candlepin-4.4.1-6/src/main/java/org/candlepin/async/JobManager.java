/*
 * Copyright (c) 2009 - 2023 Red Hat, Inc.
 *
 * This software is licensed to you under the GNU General Public License,
 * version 2 (GPLv2). There is NO WARRANTY for this software, express or
 * implied, including the implied warranties of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. You should have received a copy of GPLv2
 * along with this software; if not, see
 * http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt.
 *
 * Red Hat trademarks are not licensed under GPLv2. No permission is
 * granted to use or replicate Red Hat trademarks that are incorporated
 * in this software or its documentation.
 */
package org.candlepin.async;

import org.candlepin.audit.EventSink;
import org.candlepin.auth.JobPrincipal;
import org.candlepin.auth.Principal;
import org.candlepin.auth.SystemPrincipal;
import org.candlepin.config.ConfigProperties;
import org.candlepin.config.Configuration;
import org.candlepin.controller.mode.CandlepinModeManager;
import org.candlepin.controller.mode.CandlepinModeManager.Mode;
import org.candlepin.controller.mode.ModeChangeListener;
import org.candlepin.guice.CandlepinRequestScope;
import org.candlepin.guice.PrincipalProvider;
import org.candlepin.logging.LoggingUtil;
import org.candlepin.model.AsyncJobStatus;
import org.candlepin.model.AsyncJobStatus.JobState;
import org.candlepin.model.AsyncJobStatusCurator;
import org.candlepin.model.AsyncJobStatusCurator.AsyncJobStatusQueryArguments;
import org.candlepin.model.Owner;
import org.candlepin.model.OwnerCurator;
import org.candlepin.util.Util;

import com.google.inject.Injector;
import com.google.inject.persist.Transactional;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.jboss.resteasy.core.ResteasyContext;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.JobPersistenceException;
import org.quartz.ScheduleBuilder;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.TriggerListener;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.quartz.spi.JobFactory;
import org.quartz.spi.TriggerFiredBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.inject.Singleton;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.transaction.Status;
import javax.transaction.Synchronization;


// FIXME: The transaction management here is getting out of hand. The annotations should probably
// be removed entirely and replaced with explicit transaction management, and the protected methods
// using them should be reverted to their proper visibility (private).


/**
 * The JobManager manages the queueing, execution and general bookkeeping on jobs
 */
@Singleton
public class JobManager implements ModeChangeListener {
    private static final Logger log = LoggerFactory.getLogger(JobManager.class);

    private static final String UNKNOWN_OWNER_KEY = "-UNKNOWN-";

    private static final String QRTZ_GROUP_CONFIG = "cp_async_config";
    private static final String QRTZ_GROUP_MANUAL = "cp_async_manual";
    private static final String QRTZ_GROUP_PINSETTER = "cron group";

    private static final Object SUSPEND_KEY_DEFAULT = "default_suspend_key";
    private static final Object SUSPEND_KEY_TRIGGERED = "triggered_suspend_key";

    /** Stores our mapping of job keys to job classes */
    private static final Map<String, Class<? extends AsyncJob>> JOB_KEY_MAP = new HashMap<>();

    /**
     * Enum representing known manager states, and valid state transitions
     */
    public enum ManagerState {
        // Impl note: We have to use strings here since we can't reference enums that haven't yet
        // been defined. This is slightly less efficient than I'd like, but whatever.
        CREATED("INITIALIZED", "SHUTDOWN"),
        INITIALIZED("RUNNING", "SUSPENDED", "SHUTDOWN"),
        RUNNING("RUNNING", "SUSPENDED", "SHUTDOWN"),
        SUSPENDED("RUNNING", "SUSPENDED", "SHUTDOWN"),
        SHUTDOWN();

        private final String[] transitions;

        ManagerState(String... transitions) {
            this.transitions = transitions != null && transitions.length > 0 ? transitions : null;
        }

        public boolean isValidTransition(ManagerState state) {
            if (state != null && this.transitions != null) {
                for (String transition : this.transitions) {
                    if (transition.equals(state.name())) {
                        return true;
                    }
                }
            }

            return false;
        }

        public boolean isTerminal() {
            return this.transitions == null;
        }
    }

    /**
     * Bridge between the Quartz job and Candlepin job execution interfaces
     */
    private static class QuartzJobExecutor implements Job, JobFactory, TriggerListener {
        private final JobManager manager;

        public QuartzJobExecutor(JobManager manager) {
            this.manager = manager;
        }

        @Override
        public Job newJob(TriggerFiredBundle bundle, Scheduler scheduler) throws SchedulerException {
            return this;
        }

        @Override
        public void execute(org.quartz.JobExecutionContext context) throws org.quartz.JobExecutionException {
            String jobKey = context.getJobDetail().getKey().getName();
            Principal principal = new JobPrincipal(SystemPrincipal.NAME + "." + jobKey);
            ResteasyContext.pushContext(Principal.class, principal);

            try {
                log.trace("Queuing scheduled job: {}", jobKey);
                this.manager.queueJob(JobConfig.forJob(jobKey));
            }
            catch (JobException e) {
                String errmsg = String.format("Unable to queue scheduled job: %s", jobKey);
                throw new org.quartz.JobExecutionException(errmsg, e);
            }
        }

        @Override
        public String getName() {
            return this.getClass().getSimpleName();
        }

        @Override
        public void triggerComplete(Trigger trigger, org.quartz.JobExecutionContext context,
            Trigger.CompletedExecutionInstruction triggerInstructionCode) {
            // Intentionally left empty
        }

        @Override
        public void triggerFired(Trigger trigger, org.quartz.JobExecutionContext context) {
            // Intentionally left empty
        }

        @Override
        public void triggerMisfired(Trigger trigger) {
            String jobKey = trigger.getKey().getName();

            log.warn("Trigger misfired for job: {} [start: {}, end: {}, next fire time: {}, " +
                "final fire time: {}, priority: {}, misfire instruction: {}]",
                jobKey, trigger.getStartTime(), trigger.getEndTime(), trigger.getNextFireTime(),
                trigger.getFinalFireTime(), trigger.getPriority(), trigger.getMisfireInstruction());
        }

        @Override
        public boolean vetoJobExecution(Trigger trigger, org.quartz.JobExecutionContext context) {
            return false;
        }
    }

    /**
     * The JobMessageSynchronizer commits or rolls back a messenger transaction upon the completion
     * of a database transaction.
     */
    private static class JobMessageSynchronizer implements Synchronization {
        /** An array of states that are valid to synchronize against */
        public static final TransactionStatus[] ACTIVE_STATES = {
            TransactionStatus.ACTIVE, TransactionStatus.MARKED_ROLLBACK
        };

        private final JobMessageDispatcher dispatcher;

        public JobMessageSynchronizer(JobMessageDispatcher dispatcher) {
            this.dispatcher = dispatcher;
        }

        @Override
        public void afterCompletion(int status) {
            try {
                switch (status) {
                    case Status.STATUS_COMMITTED:
                        log.debug("Transaction committed");
                        this.dispatcher.commit();
                        break;

                    case Status.STATUS_ROLLEDBACK:
                        log.debug("Transaction rolled back");
                        this.dispatcher.rollback();
                        break;

                    default:
                        // We don't care about other states, and they shouldn't be provided here anyhow
                        log.debug("Received unexpected transaction completion status: {}", status);
                }
            }
            catch (JobMessageDispatchException e) {
                log.error("Error occurred while attempting to synchronize database and message bus", e);
            }
        }

        @Override
        public void beforeCompletion() {
            // Intentionally left empty
        }
    }

    /**
     * Registers the given class for the specified key. If the key was already registered to
     * another class, the previously registered class will be returned.
     *
     * @param jobKey
     *  The key under which to register the job class
     *
     * @param jobClass
     *  The job class to register
     *
     * @throws IllegalArgumentException
     *  if jobKey is null or empty, or jobClass is null
     *
     * @return
     *  the job class previously registered to the given key, or null if the key was not already
     *  registered
     */
    public static Class<? extends AsyncJob> registerJob(String jobKey, Class<? extends AsyncJob> jobClass) {
        if (jobKey == null || jobKey.isEmpty()) {
            throw new IllegalArgumentException("jobKey is null or empty");
        }

        if (jobClass == null) {
            throw new IllegalArgumentException("jobClass is null");
        }

        log.info("Registering job: {}: {}", jobKey, jobClass.getCanonicalName());
        return JOB_KEY_MAP.put(jobKey, jobClass);
    }

    /**
     * Removes the registration for the specified job key, if present. If the given key is not
     * registered to any job class, this function returns null.
     *
     * @param jobKey
     *  The job key to unregister
     *
     * @throws IllegalArgumentException
     *  if jobKey is null or empty
     *
     * @return
     *  the job class previously registered to the given key, or null if the key was not already
     *  registered
     */
    public static Class<? extends AsyncJob> unregisterJob(String jobKey) {
        if (jobKey == null || jobKey.isEmpty()) {
            throw new IllegalArgumentException("jobKey is null or empty");
        }

        return JOB_KEY_MAP.remove(jobKey);
    }

    /**
     * Fetches the job class registered to the specified key. If the key is not registered, this
     * function returns null.
     *
     * @param jobKey
     *  The key for which to fetch the job class
     *
     * @throws IllegalArgumentException
     *  if jobKey is null or empty
     *
     * @return
     *  the job class registered to the given key, or null if the key is not registered
     */
    public static Class<? extends AsyncJob> getJobClass(String jobKey) {
        if (jobKey == null || jobKey.isEmpty()) {
            throw new IllegalArgumentException("jobKey is null or empty");
        }

        return JOB_KEY_MAP.get(jobKey);
    }

    private final Configuration configuration;
    private final SchedulerFactory schedulerFactory;
    private final CandlepinModeManager modeManager;
    private final AsyncJobStatusCurator jobCurator;
    private final OwnerCurator ownerCurator;
    private final JobMessageDispatcher dispatcher;
    private final JobMessageReceiver receiver;
    private final CandlepinRequestScope candlepinRequestScope;
    private final PrincipalProvider principalProvider;
    private final Injector injector;
    private final Provider<EventSink> eventSinkProvider;

    private ManagerState state;
    private JobMessageSynchronizer synchronizer;
    private QuartzJobExecutor qrtzExecutor;
    private Scheduler scheduler;
    private ThreadLocal<Map<String, String>> mdcState;
    private Set<Object> suspendKeys;

    /**
     * Creates a new JobManager instance
     */
    @Inject
    public JobManager(
        Configuration configuration,
        SchedulerFactory schedulerFactory,
        CandlepinModeManager modeManager,
        AsyncJobStatusCurator jobCurator,
        OwnerCurator ownerCurator,
        JobMessageDispatcher dispatcher,
        JobMessageReceiver receiver,
        PrincipalProvider principalProvider,
        CandlepinRequestScope scope,
        Provider<EventSink> eventSink,
        Injector injector) {

        this.configuration = Objects.requireNonNull(configuration);
        this.schedulerFactory = Objects.requireNonNull(schedulerFactory);
        this.modeManager = Objects.requireNonNull(modeManager);
        this.jobCurator = Objects.requireNonNull(jobCurator);
        this.ownerCurator = Objects.requireNonNull(ownerCurator);
        this.dispatcher = Objects.requireNonNull(dispatcher);
        this.receiver = Objects.requireNonNull(receiver);
        this.candlepinRequestScope = Objects.requireNonNull(scope);
        this.principalProvider = Objects.requireNonNull(principalProvider);
        this.eventSinkProvider = Objects.requireNonNull(eventSink);
        this.injector = Objects.requireNonNull(injector);

        this.state = ManagerState.CREATED;
        this.qrtzExecutor = new QuartzJobExecutor(this);
        this.mdcState = new ThreadLocal<>();
        this.suspendKeys = new HashSet<>();

        this.synchronizer = new JobMessageSynchronizer(this.dispatcher);
    }

    /**
     * Attempts to fetch the name of this node. The node name is determined by first checking if the
     * node has been explicitly named in candlepin.conf via the node_name configuration. If that has
     * not been set, this will attempt to use the local hostname.
     *
     * @return
     *  the name of this Candlepin node
     */
    private String getNodeName() {
        String name = this.configuration.getString(ConfigProperties.ASYNC_JOBS_NODE_NAME);
        return name != null ? name : Util.getHostname();
    }

    /**
     * Perform final initialization once that could not be performed during construction. Once this
     * method has been called, it should not be called again.
     *
     * @throws IllegalStateException
     *  if this JobManager has already been initialized, or is otherwise in a state where
     *  initialization cannot be performed
     */
    public synchronized void initialize() throws StateManagementException {
        // TODO: We're probably going to want to add some bits to avoid queuing/scheduling new jobs
        // during shutdown. We probably also want to have a means of closing the message listeners
        // backing all of this as well, so we don't try to execute jobs before we're initialized or
        // during/after shutdown.

        // Perform state transition
        this.validateStateTransition(ManagerState.INITIALIZED);

        try {
            log.info("Initializing job manager");

            if (this.state == ManagerState.CREATED) {
                if (this.isSchedulerEnabled()) {
                    // Initialize the scheduler factory with the Quartz-specific configuration, if possible
                    if (this.schedulerFactory instanceof StdSchedulerFactory) {
                        Properties quartzConfig = this.configuration.toProperties();
                        ((StdSchedulerFactory) this.schedulerFactory).initialize(quartzConfig);
                    }

                    if (this.scheduler == null || this.scheduler.isShutdown()) {
                        this.scheduler = this.schedulerFactory.getScheduler();
                    }

                    this.synchronizeJobSchedule();
                    this.scheduler.setJobFactory(this.qrtzExecutor);

                    // Register our executor as a trigger listener, so we can log certain Quartz
                    // events
                    this.scheduler.getListenerManager()
                        .addTriggerListener(this.qrtzExecutor);
                }

                if (!this.receiver.isInitialized()) {
                    this.receiver.initialize(this);
                }

                this.modeManager.registerModeChangeListener(this);

                // Check if Candlepin's current operating mode would prevent us from starting
                // normally.
                if (this.modeManager.getCurrentMode() == Mode.SUSPEND) {
                    this.suspendKeys.add(SUSPEND_KEY_TRIGGERED);
                }

                // Attempt to restore any jobs which were running on this node but did not get
                // to gracefully shutdown.
                this.recoverAbandonedJobs();
            }

            log.info("Job manager initialization complete");
            this.state = ManagerState.INITIALIZED;
        }
        catch (Exception e) {
            String errmsg = "Unexpected exception occurred during initialization";

            log.error(errmsg, e);

            try {
                if (this.scheduler != null) {
                    this.scheduler.shutdown();
                    this.scheduler = null;
                }
            }
            catch (SchedulerException se) {
                log.error("Unable to shutdown quartz scheduler while processing other exceptions", se);
            }

            throw new StateManagementException(this.state, ManagerState.INITIALIZED, errmsg, e);
        }
    }

    /**
     * Attempts to recover all jobs that were abandoned by this node if it shutdown abnormally
     * while executing jobs. Any jobs in the RUNNING state with an executor set to this node
     * will have their state forcefully rewound to QUEUED in an attempt to allow the task to be
     * rerun.
     */
    private void recoverAbandonedJobs() {
        AsyncJobStatusQueryArguments queryArgs = new AsyncJobStatusQueryArguments()
            .setJobStates(Collections.singleton(JobState.RUNNING))
            .setExecutors(Collections.singleton(this.getNodeName()));

        // Impl note: this violates normal state transitions, but we're trying to recover from an
        // ungraceful shutdown in which our process was terminated while a job was running. We'll
        // set the job's state to QUEUED, which will allow us to pick up the job and run it again
        // next time the message is received. If the message has been lost, then the job cleaner
        // will eventually nuke this job as part of its non-terminal job aborting step.
        for (AsyncJobStatus job : this.jobCurator.findJobs(queryArgs)) {
            log.warn("Recovering abandoned job: {}", job);

            job.setState(JobState.QUEUED);
            this.jobCurator.merge(job);
        }
    }

    /**
     * Attempts to start or resume this job manager by lifting the default suspend key. If all
     * suspend keys have been lifted, the job manager will be resumed. If the job manager is not
     * currently in a suspended state, this method silently returns.
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized or has already shutdown
     */
    public void start() throws StateManagementException {
        this.start(SUSPEND_KEY_DEFAULT);
    }

    /**
     * Attempts to start or resume this job manager by lifting the specified suspend key. If all
     * suspend keys have been lifted, the job manager will be resumed. If the job manager is not
     * currently in a suspended state, this method silently returns.
     *
     * @param key
     *  the suspend key to lift; must not be null
     *
     * @throws IllegalArgumentException
     *  if the specified suspend key is null
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized, has already shutdown or Candlepin is
     *  in suspend mode
     */
    public synchronized void start(Object key) throws StateManagementException {
        log.trace("Start request received with suspend key: {}", key);

        if (key == null) {
            throw new IllegalArgumentException("suspend key is null");
        }

        this.validateStateTransition(ManagerState.RUNNING);

        try {
            if (this.state == ManagerState.INITIALIZED || this.state == ManagerState.SUSPENDED) {
                if (this.suspendKeys.remove(key)) {
                    log.debug("Lifted job manager suspend key: {} ({} remaining)", key,
                        this.suspendKeys.size());
                }

                if (this.suspendKeys.isEmpty()) {
                    String startType = (this.state == ManagerState.INITIALIZED ? "started" : "resumed");
                    log.info("Job manager {}", startType);

                    if (this.isSchedulerEnabled()) {
                        this.scheduler.start();
                    }

                    this.receiver.start();

                    this.state = ManagerState.RUNNING;
                }
                else {
                    log.debug("Job manager still suspended by {} keys", this.suspendKeys.size());
                    this.state = ManagerState.SUSPENDED;
                }
            }
        }
        catch (Exception e) {
            String errmsg = "Unexpected exception occurred while starting job manager";

            log.error(errmsg, e);
            throw new StateManagementException(this.state, ManagerState.RUNNING, errmsg, e);
        }
    }

    /**
     * Attempts to resume this job manager by lifting the default suspend key. If all suspend keys
     * have been lifted, the job manager will be resumed. If the job manager is not currently in a
     * suspended state, this method silently returns.
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized or has already shutdown
     */
    public void resume() throws StateManagementException {
        this.start(SUSPEND_KEY_DEFAULT);
    }

    /**
     * Attempts to resume this job manager by lifting the specified suspend key. If all suspend keys
     * have been lifted, the job manager will be resumed. If the job manager is not currently in a
     * suspended state, this method silently returns.
     *
     * @param key
     *  the suspend key to lift; cannot be null
     *
     * @throws IllegalArgumentException
     *  if the specified suspend key is null
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized, has already shutdown or Candlepin is
     *  in suspend mode
     */
    public void resume(Object key) throws StateManagementException {
        this.start(key);
    }

    /**
     * Suspends this job manager with the default suspend key, preventing jobs from being executed
     * until the manager is resumed by lifting all applied suspend keys. If the job manager is
     * already suspended, this method silently returns.
     * <p></p>
     * Suspending will not stop currently executing jobs, nor will it prevent new jobs from being
     * scheduled or queued for later execution. If a scheduled job's next appointed time occurs
     * while the manager is suspended, the collision will be resolved according to the job's
     * constraints.
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized or has already shutdown
     */
    public void suspend() throws StateManagementException {
        this.suspend(SUSPEND_KEY_DEFAULT);
    }

    /**
     * Suspends this job manager with the specified suspend key, preventing jobs from being executed
     * until the manager is resumed by lifting all applied suspend keys. If the job manager is
     * already suspended, this method silently returns.
     * <p></p>
     * Suspending will not stop currently executing jobs, nor will it prevent new jobs from being
     * scheduled or queued for later execution. If a scheduled job's next appointed time occurs
     * while the manager is suspended, the collision will be resolved according to the job's
     * constraints.
     * <p></p>
     * The key provided to suspend job execution can be any object except those with non-standard,
     * or inconsistent implementations of equals and/or hashCode.
     *
     * @param key
     *  the suspend key to apply; cannot be null
     *
     * @throws IllegalArgumentException
     *  if the specified suspend key is null
     *
     * @throws IllegalStateException
     *  if this JobManager has not been initialized or has already shutdown
     */
    public synchronized void suspend(Object key) throws StateManagementException {
        log.trace("Suspend request received with key: {}", key);

        if (key == null) {
            throw new IllegalArgumentException("suspend key is null");
        }

        this.validateStateTransition(ManagerState.SUSPENDED);

        try {
            if (this.suspendKeys.add(key)) {
                log.debug("Suspending job manager with key: {}", key);
            }

            if (this.state == ManagerState.INITIALIZED || this.state == ManagerState.RUNNING) {
                this.receiver.suspend();

                if (this.isSchedulerEnabled()) {
                    this.scheduler.standby();
                }

                log.info("Job manager suspended");
                this.state = ManagerState.SUSPENDED;
            }
        }
        catch (Exception e) {
            String errmsg = "Unexpected exception occurred while pausing job manager";

            log.error(errmsg, e);
            throw new StateManagementException(this.state, ManagerState.SUSPENDED, errmsg, e);
        }
    }

    /**
     * Shuts down this job manager, preventing jobs from being scheduled, queued or executed.
     * Shutting down will not stop currently executing jobs, but will stop this manager from
     * processing any new execution requests.
     *
     * @throws IllegalStateException
     *  if this JobManager has already been shutdown, or is otherwise in a state where a shut
     *  down cannot be performed
     */
    public synchronized void shutdown() throws StateManagementException {
        // TODO: actually do something with this

        this.validateStateTransition(ManagerState.SHUTDOWN);

        try {
            log.info("Shutting down job manager");

            if (this.state == ManagerState.RUNNING || this.state == ManagerState.SUSPENDED) {
                this.dispatcher.shutdown();
                this.receiver.shutdown();

                if (this.isSchedulerEnabled()) {
                    this.scheduler.shutdown(true);
                }
            }

            log.info("Job manager shut down");
            this.state = ManagerState.SHUTDOWN;
        }
        catch (Exception e) {
            String errmsg = "Unexpected exception occurred while shutting down job manager";

            log.error(errmsg, e);
            throw new StateManagementException(this.state, ManagerState.SHUTDOWN, errmsg, e);
        }
    }

    /**
     * Fetches the current state of this job manager.
     *
     * @return
     *  the current state of this job manager
     */
    public synchronized ManagerState getManagerState() {
        return this.state;
    }

    /**
     * Checks if the target state is a valid state from which the current state can transition.
     *
     * @param target
     *  The target state to enter
     *
     * @throws IllegalStateException
     *  if the target state is an invalid transition from the current state
     */
    private void validateStateTransition(ManagerState target) {
        if (!this.state.isValidTransition(target)) {
            String errmsg = String.format("Cannot transition manager state from \"%s\" to \"%s\"",
                this.state.name(), target.name());

            log.error(errmsg);
            throw new IllegalStateException(errmsg);
        }
    }

    /**
     * Checks if the job scheduler is enabled.
     * <p></p>
     * The scheduler controls whether or jobs will be automatically fired at their scheduled times.
     * Disabling the scheduler will *not* prevent jobs from being scheduled by other means (on event
     * or manual execution), but it will prevent this node from triggering jobs according to any
     * schedule set for them.
     *
     * @return
     *  true if the scheduler is enabled; false otherwise
     */
    public boolean isSchedulerEnabled() {
        return this.configuration.getBoolean(ConfigProperties.ASYNC_JOBS_SCHEDULER_ENABLED);
    }

    /**
     * Ensures the jobs automatically scheduled according to the system configuration are in sync
     * with the current configuration.
     */
    private void synchronizeJobSchedule() throws SchedulerException {
        // TODO: Quartz isn't doing much for us here. Perhaps we'd be better off with our own
        // minimalistic scheduler, since we only need cron, delay and interval scheduling. Quartz
        // seems pretty heavy considering how we actually use it.

        Set<JobKey> qrtzJobKeys = this.scheduler.getJobKeys(GroupMatcher.anyJobGroup());
        log.debug("Checking {} existing scheduled jobs...", qrtzJobKeys.size());

        Map<String, String> schedules = findJobSchedules();

        Set<String> existingJobs = findExistingJobs(qrtzJobKeys, schedules);
        Set<JobKey> unschedule = qrtzJobKeys.stream()
            .filter(jobKey -> !existingJobs.contains(jobKey.getName()))
            .collect(Collectors.toSet());

        unscheduleBadJobs(unschedule);

        // Schedule new jobs
        for (Map.Entry<String, String> entry : schedules.entrySet()) {
            String jobKey = entry.getKey();
            String schedule = entry.getValue();

            boolean manual = ConfigProperties.ASYNC_JOBS_MANUAL_SCHEDULE.equalsIgnoreCase(schedule);

            // If the job is not configured for scheduled execution, or is already scheduled, skip it.
            if (schedule == null || manual || existingJobs.contains(jobKey)) {
                continue;
            }

            try {
                ScheduleBuilder<CronTrigger> qtzSchedule = CronScheduleBuilder.cronSchedule(schedule)
                    .withMisfireHandlingInstructionDoNothing();

                Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity(jobKey, QRTZ_GROUP_CONFIG)
                    .withSchedule(qtzSchedule)
                    .build();

                JobDetail detail = org.quartz.JobBuilder.newJob(QuartzJobExecutor.class)
                    .withIdentity(jobKey, QRTZ_GROUP_CONFIG)
                    .build();

                this.scheduler.scheduleJob(detail, trigger);

                log.info("Scheduled job \"{}\" with cron schedule: {}", jobKey, schedule);
            }
            catch (Exception e) {
                log.error("Unable to schedule job \"{}\":", jobKey, e);
                throw new RuntimeException(e);
            }
        }
    }

    private Set<String> findExistingJobs(Set<JobKey> qrtzJobKeys, Map<String, String> schedules)
        throws SchedulerException {
        Set<String> existing = new HashSet<>();
        if (qrtzJobKeys == null || qrtzJobKeys.isEmpty()) {
            return existing;
        }

        GroupMatcher<JobKey> cronJobMatcher = GroupMatcher.jobGroupEquals(QRTZ_GROUP_CONFIG);

        log.debug("Checking {} existing scheduled jobs...", qrtzJobKeys.size());

        for (JobKey key : qrtzJobKeys) {
            if (!jobExists(key)) {
                continue;
            }

            // Continue checking the job schedule if it's one of ours
            if (!cronJobMatcher.isMatch(key)) {
                continue;
            }

            // Impl note: using the key's name as the job key works, but it limits each
            // job to exactly one schedule, which may or may not be a good thing.
            String schedule = schedules.get(key.getName());

            if (!hasValidSchedule(key, schedule)) {
                continue;
            }

            // Job exists and matches our schedule, we can skip it later
            existing.add(key.getName());
        }

        return existing;
    }

    private boolean jobExists(JobKey key) throws SchedulerException {
        // Verify the job exists and is in a valid state by loading its job detail
        try {
            this.scheduler.getJobDetail(key);
            return true;
        }
        catch (JobPersistenceException e) {
            log.error("Unable to load job detail for job, removing it from the scheduler: {}",
                key.getName(), e);
            return false;
        }
    }

    private boolean hasValidSchedule(JobKey key, String schedule) throws SchedulerException {
        // Impl note: using the key's name as the job key works, but it limits each
        // job to exactly one schedule, which may or may not be a good thing.

        boolean manual = ConfigProperties.ASYNC_JOBS_MANUAL_SCHEDULE.equalsIgnoreCase(schedule);

        // If the job is no longer configured for scheduled execution, remove it from the
        // scheduler
        if (schedule == null || manual) {
            return false;
        }

        Trigger trigger = this.scheduler.getTrigger(
            TriggerKey.triggerKey(key.getName(), key.getGroup()));

        // Check that the job has a trigger, it's a cron trigger, and the schedule matches
        // the schedule in the current configuration
        return trigger instanceof CronTrigger &&
            ((CronTrigger) trigger).getCronExpression().equals(schedule);
    }


    private void unscheduleBadJobs(Set<JobKey> unschedule) throws SchedulerException {
        for (JobKey key : unschedule) {
            List<? extends Trigger> jobTriggers = this.scheduler.getTriggersOfJob(key);

            if (!jobTriggers.isEmpty()) {
                this.scheduler.unscheduleJobs(jobTriggers
                    .stream()
                    .map(Trigger::getKey)
                    .toList());
            }
            else {
                this.scheduler.deleteJob(key);
            }

            log.info("Removed existing schedule for job: {}", key.getName());
        }
    }

    private Map<String, String> findJobSchedules() {
        Map<String, String> config = this.configuration.getValuesByPrefix(ConfigProperties.ASYNC_JOBS_PREFIX);
        return config.entrySet().stream()
            .filter(entry -> entry.getKey().endsWith(".schedule"))
            .collect(Collectors.toMap(
                this::getJobKey,
                Map.Entry::getValue
            ));

    }

    private String getJobKey(Map.Entry<String, String> entry) {
        String[] split = Util.stripPrefix(entry.getKey(), ConfigProperties.ASYNC_JOBS_PREFIX)
            .split("\\.");
        return split[0];
    }

    /**
     * Builds an AsyncJobStatus instance from the given job details. The job status will not be
     * a managed entity and will need to be manually persisted by the caller.
     *
     * @param builder
     *  The JobConfig to use to build the job status
     *
     * @throws IllegalArgumentException
     *  if detail is null
     *
     * @return
     *  the newly constructed, unmanaged AsyncJobStatus instance
     */
    private AsyncJobStatus buildJobStatus(JobConfig builder) {
        if (builder == null) {
            throw new IllegalArgumentException("job builder is null");
        }

        AsyncJobStatus job = new AsyncJobStatus();
        job.setState(JobState.CREATED);

        job.setJobKey(builder.getJobKey());
        job.setName(builder.getJobName() != null ? builder.getJobName() : builder.getJobKey());
        job.setGroup(builder.getJobGroup());
        job.setContextOwner(builder.getContextOwner());

        // Add environment-specific metadata...
        job.setOrigin(this.getNodeName());
        Principal principal = this.principalProvider.get();
        job.setPrincipalName(principal != null ? principal.getName() : null);

        String csid = MDC.get(LoggingUtil.MDC_CSID_KEY);
        job.setCorrelationId(csid != null && !csid.isEmpty() ? csid : null);

        // Set logging configuration...
        job.setLogLevel(builder.getLogLevel());
        job.logExecutionDetails(builder.logExecutionDetails());

        // Retry and runtime configuration...
        job.setMaxAttempts(builder.getRetryCount() + 1);
        job.setJobArguments(builder.getJobArguments());

        return job;
    }

    /**
     * Performs a job state transition after validating the transition is a valid one.
     *
     * @param status
     *  the job status to update
     *
     * @param state
     *  the job state to transition to
     *
     * @throws IllegalStateException
     *  if the state transition is not valid
     *
     * @return
     *  a refrence to the provided job status
     */
    private AsyncJobStatus setJobState(AsyncJobStatus status, JobState state) {
        JobState currentState = status.getState();

        if (!currentState.isValidTransition(state)) {
            String errmsg = String.format("Cannot transition from state %s to %s",
                currentState.name(), state.name());

            throw new IllegalStateException(errmsg);
        }

        return status.setState(state);
    }

    /**
     * Fetches the job status associated with the specified job ID. If no such job status could be
     * found, this method returns null.
     *
     * @param jobId
     *  the ID of the job to fetch
     *
     * @return
     *  the job status associated with the specified job ID, or null if no such job status could be
     *  found
     */
    public AsyncJobStatus findJob(String jobId) {
        return this.jobCurator.get(jobId);
    }

    /**
     * Fetches a collection of jobs based on the provided filter data in the query builder. If the
     * query builder is null or contains no arguments, this method will return all known async jobs.
     *
     * @param queryArgs
     *  an AsyncJobStatusQueryArguments instance containing the various arguments or filters to use
     *  to select jobs
     *
     * @return
     *  a list of jobs matching the provided query arguments/filters
     */
    public List<AsyncJobStatus> findJobs(AsyncJobStatusQueryArguments queryArgs) {
        return this.jobCurator.findJobs(queryArgs);
    }

    /**
     * Queues a job to be run on any Candlepin node backed by the same database as this node, and
     * is configured to process jobs matching the type of the specified job. If multiple nodes are
     * able to process a given job, there is no mechanism to guarantee consistently repeatable
     * behavior as to which node will actually execute the job.
     * <p></p>
     * If the specified job is one which is unique by some criteria, and a matching job is already
     * in the queue or currently executing, a new job will not be queued and the existing job's
     * job status will be returned instead.
     *
     * @param config
     *  A JobConfig instance representing the configuration of the job to queue
     *
     * @return
     *  an AsyncJobStatus instance representing the queued job's status, or the status of the
     *  existing job if it already exists
     */
    @Transactional
    public AsyncJobStatus queueJob(JobConfig config) throws JobException {
        ManagerState state = this.getManagerState();
        if (state != ManagerState.RUNNING) {
            // Check if we're paused. If so, and if the "queue while paused" config is not set,
            // throw our usual ISE
            if (state != ManagerState.SUSPENDED ||
                !this.configuration.getBoolean(ConfigProperties.ASYNC_JOBS_QUEUE_WHILE_SUSPENDED)) {

                String msg = String.format("Jobs cannot be queued while the manager is in the %s state",
                    state);

                throw new IllegalStateException(msg);
            }
        }

        if (config == null) {
            throw new IllegalArgumentException("job config is null");
        }

        config.validate();

        // TODO:
        // Don't allow queueing jobs which are disabled? Should that be disabled entirely or not
        // runnable by this node?

        AsyncJobStatus status = this.buildJobStatus(config);

        try {
            // Check if the queueing is blocked by constraints
            Collection<JobConstraint> constraints = config.getConstraints();
            Set<String> blockingJobIds = new HashSet<>();

            if (constraints != null && !constraints.isEmpty()) {
                for (JobConstraint constraint : constraints) {
                    Collection<String> blocking = constraint.test(this.jobCurator, status);

                    if (blocking != null) {
                        blockingJobIds.addAll(blocking);
                    }
                }
            }

            // Persist the job status so that the ID will be generated.
            status = this.jobCurator.create(status);

            if (blockingJobIds.isEmpty()) {
                // Build and send the job message and update the job state accordingly
                status = this.postJobStatusMessage(status);
                log.info("Job queued: {}", status);
            }
            else {
                // TODO: Add support for the WAITING option. For now, always default to ABORTED

                String jobIds = blockingJobIds.stream()
                    .collect(Collectors.joining(", "));

                StringBuilder errmsg = new StringBuilder("Job blocked by the following existing jobs: ")
                    .append(jobIds);

                this.updateJobStatus(status, JobState.ABORTED, errmsg.toString());

                log.info("Unable to queue job: {}; blocked by the following existing jobs: {}",
                    status.getName(), jobIds);
            }
        }
        catch (JobStateManagementException e) {
            if (log.isDebugEnabled()) {
                log.error("Unable to update state for job: {}; leaving job in its previous state for " +
                    "state resync upon execution", status.getName(), e);
            }
            else {
                log.error("Unable to update state for job: {}; leaving job in its previous state for " +
                    "state resync upon execution", status.getName(), e);
            }

            // We were unable to update the state from CREATED->QUEUED, but we were able to send
            // the message to Artemis. We *should* be fine once the job executes and corrects
            // itself. The job will skip the QUEUED state and transition right into RUNNING, but
            // that's fine... I guess.

            // Manually update the state just to be certain. This won't persist, but at least our
            // output will be consistent.
            this.setJobState(status, JobState.QUEUED);
        }
        catch (JobMessageDispatchException e) { // Temporary exception branch
            log.error("Unable to dispatch job message for new job: {}; deleting job and returning",
                status.getName(), e);

            // We created the job, but were unable to send the job to Artemis. The job is dead
            // at this point. We *could* retry, but at the time of writing, we have no mechanism
            // for enabling retry or async messaging (comes with scheduling). As such, we'll
            // kill the job

            this.jobCurator.delete(status);
            throw e;
        }
        catch (Exception e) {
            log.error("Unexpected exception occurred while queueing job: {}", status.getName(), e);

            // Uh oh. If we're here, something very very bad has happened. This probably indicates
            // the database is unavailable or we, otherwise, cannot persist the AsyncJobStatus
            // instance. We'd delete it, but that'll likely fail, too. Best thing to do here is
            // just return the job status with the FAILED info.

            // If this occurs do to some other unexpected failure, we'll have some state cleanup
            // to deal with, probably.

            throw new JobException(e, true);
        }

        // Done!
        return status;
    }

    /**
     * Creates and dispatches a job message for the given job status, then updates the state of
     * the job to QUEUED.
     *
     * @param status
     *  The job for which to dispatch a job message
     *
     * @return
     *  the updated job status
     */
    @Transactional
    protected AsyncJobStatus postJobStatusMessage(AsyncJobStatus status)
        throws JobStateManagementException, JobMessageDispatchException {

        // Impl note:
        // To minimize the possibility of having a race condition between updating the job status
        // in the database and sending the job message to Artemis, this method should always run
        // within the context of a DB transaction. At the time of writing, this method is annotated
        // with the @Transactional tag to force this, but it can be removed if, and only if, other
        // measures are taken to ensure we can properly delay the sending of the job message until
        // after the database is updated.

        try {
            // Build and send the job message
            JobMessage message = new JobMessage(status.getId(), status.getJobKey());
            this.dispatcher.postJobMessage(message);

            // Update the job's status
            status = this.updateJobStatus(status, JobState.QUEUED, null);

            // Register our synchronizer to commit or rollback the dispatcher based on whether
            // or not the current DB transaction completes
            Session session = this.jobCurator.currentSession();
            Transaction transaction = session.getTransaction();

            if (transaction != null &&
                transaction.getStatus().isOneOf(JobMessageSynchronizer.ACTIVE_STATES)) {

                // We have an active transaction (probably); register the synchronizer to pass
                // through the commit/rollback to the messaging bus.
                transaction.registerSynchronization(this.synchronizer);
            }
            else {
                // No (active) transaction, immediately commit the messages. This should never happen.
                log.warn("No active transaction while posting job messages; dispatching immediately.");
                this.dispatcher.commit();
            }

            return status;
        }
        catch (JobMessageDispatchException e) {
            log.error("Job \"{}\" could not be queued; failed to dispatch job message", status.getName(), e);

            this.updateJobStatus(status, JobState.ABORTED, e.toString());

            throw e;
        }
    }

    /**
     * Executes the specified job immediately on this Candlepin node, skipping any filtering or
     * deduplication mechanisms.
     * <p></p>
     * <strong>Note</strong>: Generally, this method should not be called directly, and jobs should
     * be queued using the <tt>queueJob</tt> method instead.
     *
     * @param message
     *  the JobMessage containing the information about the job that should be executed.
     *
     * @return
     *  a JobStatus instance representing the job's status
     */
    public AsyncJobStatus executeJob(JobMessage message) throws JobException {
        ManagerState state = this.getManagerState();
        if (state != ManagerState.RUNNING) {
            String msg = String.format("Jobs cannot be executed while the manager is in the %s state", state);
            throw new IllegalStateException(msg);
        }

        AsyncJobStatus status = this.fetchJobStatus(message);

        // If the job was canceled, just return. No need to do anything special here.
        if (status.getState() == JobState.CANCELED) {
            log.debug("Skipping canceled job: {} ({})", status.getJobKey(), status.getId());
            return status;
        }

        try {
            this.setupJobRuntimeEnvironment(status);

            // Maybe in this case it'd be better to attempt to use the job key as the job class
            // rather than failing directly. This would allow use of aliases and explicit job
            // classes.
            Class<? extends AsyncJob> jobClass = getJobClass(status.getJobKey());

            if (jobClass == null) {
                String errmsg = String.format("No registered job class for job: %s", status.getJobKey());

                this.updateJobStatus(status, JobState.FAILED, errmsg);

                log.error(errmsg);
                throw new JobInitializationException(errmsg, true);
            }

            AsyncJob job = injector.getInstance(jobClass);

            if (job == null) {
                String errmsg = String.format("Unable to instantiate job class \"%s\" for job: %s",
                    jobClass.getName(), status.getJobKey());

                log.error(errmsg);
                throw new JobInitializationException(errmsg);
            }

            status.setExecutor(this.getNodeName());
            status.incrementAttempts();
            status.setStartTime(new Date());
            status.setEndTime(null);
            status = this.updateJobStatus(status, JobState.RUNNING, null);

            // Impl note: We need to be sure we do not have a transaction open at this point
            EntityTransaction transaction = this.jobCurator.getTransaction();
            if (transaction != null && transaction.isActive()) {
                throw new IllegalStateException("A remnant transaction is open before executing job");
            }

            if (status.logExecutionDetails()) {
                log.info("Starting job \"{}\" using class: {}", status.getName(), jobClass.getName());
            }

            EventSink eventSink = this.eventSinkProvider.get();
            try {
                job.execute(new JobExecutionContext(status));

                // If a transaction was left open, we should scream about it. Note that this will
                // cause the job to fail if the session cannot be terminated cleanly.
                this.checkPostJobExecutionTransactionStatus(status);
            }
            catch (JobExecutionException e) {
                boolean retry = !e.isTerminal() && status.getAttempts() < status.getMaxAttempts();
                status = this.processJobFailure(status, eventSink, e, retry);

                throw e;
            }
            catch (Throwable e) {
                boolean retry = !(e instanceof Error) &&
                    status.getAttempts() < status.getMaxAttempts();

                status = this.processJobFailure(status, eventSink, e, retry);
                throw new JobExecutionException(e);
            }

            eventSink.sendEvents();
            status.setEndTime(new Date());
            status = this.updateJobStatus(status, JobState.FINISHED);

            if (status.logExecutionDetails()) {
                log.info("Job \"{}\" completed in {}ms", status.getName(), this.getJobRuntime(status));
            }

            return status;
        }
        finally {
            this.teardownJobRuntimeEnvironment();
        }
    }

    /**
     * Configures the job's runtime environment, performing the following operations:
     * <p>
     *  - Entering the new injection scope (CandlepinRequestScope)
     *  - Setting up the logging level
     *  - Injecting the job's metadata to the logging backend
     *  - Setting up the principal to use during job runtime
     *
     * @param status
     *  the job status to use to configure the runtime environment
     */
    private void setupJobRuntimeEnvironment(AsyncJobStatus status) {
        // Enter custom scope
        this.candlepinRequestScope.enter();

        // Save MDC state
        this.mdcState.set(MDC.getCopyOfContextMap());

        MDC.put(LoggingUtil.MDC_REQUEST_TYPE_KEY, "job");
        MDC.put(LoggingUtil.MDC_REQUEST_UUID_KEY, status.getId());
        MDC.put(LoggingUtil.MDC_JOB_KEY_KEY, status.getJobKey());

        // Attempt to lookup the owner
        String ownerId = status.getContextOwnerId();
        String ownerKey = null;
        String ownerLogLevel = null;

        if (ownerId != null && !ownerId.isEmpty()) {
            Owner contextOwner = this.ownerCurator.get(ownerId);

            if (contextOwner != null) {
                ownerKey = contextOwner.getKey();
                ownerLogLevel = contextOwner.getLogLevel();
            }
            else {
                log.warn("Owner ID specified for job does not exist: {}", ownerId);
                ownerKey = UNKNOWN_OWNER_KEY;
            }
        }

        // If we have an owner, override whatever metadata we've set with the actual owner's key.
        if (ownerKey != null) {
            MDC.put(LoggingUtil.MDC_OWNER_KEY, ownerKey);
        }

        // Inject the correlation ID
        MDC.put(LoggingUtil.MDC_CSID_KEY, status.getCorrelationId());

        // Set our logging level according to the following:
        // - If the job has an explicit log level set, use that
        // - If the job is running in the context of an owner and the owner has a log level set, use that
        String jobLogLevel = status.getLogLevel();

        if (jobLogLevel != null && !jobLogLevel.isEmpty()) {
            MDC.put(LoggingUtil.MDC_LOG_LEVEL_KEY, jobLogLevel);
        }
        else if (ownerLogLevel != null && !ownerLogLevel.isEmpty()) {
            MDC.put(LoggingUtil.MDC_LOG_LEVEL_KEY, ownerLogLevel);
        }

        // Setup and inject the principal
        String name = status.getPrincipalName();
        Principal principal = name != null ? new JobPrincipal(name) : new SystemPrincipal();

        ResteasyContext.pushContext(Principal.class, principal);
    }

    /**
     * Tears down the job's runtime environment, performing the following operations:
     *
     *  - Removing the job's context principal from the environment
     *  - Leaving the injection scope (CandlepinRequestScope)
     */
    private void teardownJobRuntimeEnvironment() {
        // Pop principal info
        ResteasyContext.popContextData(Principal.class);

        // Restore original MDC state
        Map<String, String> state = this.mdcState.get();
        if (state != null) {
            MDC.setContextMap(state);
        }
        else {
            MDC.clear();
        }

        // Leave scope
        this.candlepinRequestScope.exit();
    }

    /**
     * Checks that the job did not leave an active session open after completing its normal
     * execution. If a session was left open, this method attempts to commit it, or roll it back
     * if it is set to rollback only. If the session cannot be cleaned up, this method throws a
     * PersistenceException.
     *
     * @param status
     *  The AsyncJobStatus instance for the job being executed
     *
     * @throws PersistenceException
     *  if an unexpected exception occurs while terminating the session
     */
    private void checkPostJobExecutionTransactionStatus(AsyncJobStatus status) throws PersistenceException {
        try {
            EntityTransaction transaction = this.jobCurator.getTransaction();
            if (transaction != null && transaction.isActive()) {
                if (!transaction.getRollbackOnly()) {
                    log.warn("Job \"{}\" terminated with an open session; committing session...",
                        status.getName());

                    transaction.commit();
                }
                else {
                    log.warn("Job \"{}\" terminated with an open, rollback-only session; " +
                        "rolling back session...", status.getName());

                    transaction.rollback();
                }
            }
        }
        catch (PersistenceException e) {
            log.error("Unable to cleanup remnant job session; post-job database state is now undefined!", e);
            throw e;
        }
    }

    /**
     * Fetches and validates the job status associated with the given message.
     *
     * @param message
     *  The message for which to fetch the job status
     *
     * @throws JobInitializationException
     *  if the job status cannot be queried, found or it is not in a valid state
     *
     * @return
     *  the AsyncJobStatus instance associated with the given message
     */
    private AsyncJobStatus fetchJobStatus(JobMessage message) throws JobInitializationException {
        AsyncJobStatus status;

        try {
            status = this.jobCurator.get(message.getJobId());
        }
        catch (Exception e) {
            // This should only happen if the DB is down when we attempt to fetch a job from the
            // curator. This is a non-terminal error as we must assume the job is still there
            // waiting to be run
            String errmsg = String.format("Unable to query job status for message: %s", message);

            log.debug(errmsg, e);
            throw new JobInitializationException(errmsg, e, false);
        }

        if (status == null) {
            String errmsg = String.format("Unable to find job status for message: %s", message);

            log.error(errmsg);
            throw new JobInitializationException(errmsg, true);
        }

        if (status.getJobKey() == null || status.getJobKey().isEmpty()) {
            String errmsg = String.format("Incomplete job persisted for message: %s", message);

            log.error(errmsg);
            throw new JobInitializationException(errmsg, true);
        }

        JobState jobState = status.getState();

        // The "CANCELED" state is a special case we'll handle semi-silently in the execute method,
        // as it's not an error to cancel a QUEUED job, and we still want to get through the message
        // normally.
        if (jobState == null || (!JobState.CANCELED.equals(jobState) && jobState.isTerminal())) {
            String errmsg = String.format("Job \"%s\" (%s) is in an unknown or terminal state: %s",
                status.getId(), status.getJobKey(), status.getState());

            log.error(errmsg);
            throw new JobInitializationException(errmsg, true);
        }
        else if (jobState == JobState.RUNNING) {
            if (this.getNodeName().equals(status.getExecutor())) {
                // This goes against valid state transitions, but this node was the previous executor,
                // so we should be fine to go on executing it again here.
                status.setState(JobState.QUEUED);
            }
            else {
                String errmsg = String.format(
                    "Job \"%s\" (%s) is already running on host \"%s\"; ignoring execution request",
                    status.getId(), status.getJobKey(), status.getExecutor());

                log.error(errmsg);
                throw new IllegalStateException(errmsg);
            }
        }
        else if (jobState != JobState.QUEUED) {
            // Warn if we're about to execute a job that's not queued for execution (this is likely
            // just state recovery and is probably okay).
            log.warn("Job \"{}\" ({}) is in an unexpected, non-terminal state: {}", status.getId(),
                status.getJobKey(), status.getState());

            log.warn("Recovering state and executing...");
        }

        return status;
    }

    /**
     * Updates the state of the provided job status
     *
     * @param status
     *  The AsyncJobStatus to update
     *
     * @param state
     *  The state to set
     *
     * @param result
     *  The result to assign to the job
     *
     * @throws JobStateManagementException
     *  if the job state is unable to be updated due to a database failure
     *
     * @return
     *  the updated AsyncJobStatus entity
     */
    private AsyncJobStatus updateJobStatus(AsyncJobStatus status, JobState state, String result)
        throws JobStateManagementException {

        status.setJobResult(result);
        return this.updateJobStatus(status, state);
    }

    /**
     * Updates the state of the provided job status
     *
     * @param status
     *  The AsyncJobStatus to update
     *
     * @param state
     *  The state to set
     *
     * @throws JobStateManagementException
     *  if the job state is unable to be updated due to a database failure
     *
     * @return
     *  the updated AsyncJobStatus entity
     */
    @Transactional
    protected AsyncJobStatus updateJobStatus(AsyncJobStatus status, JobState state)
        throws JobStateManagementException {

        // Impl note:
        // Due to some Hibernate shenanigans, this method should only be called within the context
        // of a database transaction. If called without a transaction, the update may be lost.

        JobState initState = status.getState();

        try {
            this.setJobState(status, state);
            return this.jobCurator.merge(status);
        }
        catch (Exception e) {
            String errmsg = String.format("Unable to update job state for job \"%s\": %s -> %s",
                status.getName(), initState, state);

            log.error(errmsg, e);
            throw new JobStateManagementException(status, initState, state, errmsg, e, state.isTerminal());
        }
    }

    /**
     * Calculates the runtime of the given job. If the job has not completed its execution attempt,
     * this method returns -1;
     *
     * @param status
     *  The AsyncJobStatus for which to calculate the job runtime
     *
     * @return
     *  the runtime of the job in milliseconds, or -1 if the job has not yet completed its most
     *  recent execution attempt
     */
    private long getJobRuntime(AsyncJobStatus status) {
        Date start = status.getStartTime();
        Date end = status.getEndTime();

        return (start != null) ? end.getTime() - start.getTime() : -1;
    }

    /**
     * Processes the failure of a job by rolling back pending events and updating the job state. If
     * the job is to be retried, a new job message will be dispatched accordingly.
     *
     * @param status
     *  an AsyncJobStatus instance representing the failed job
     *
     * @param throwable
     *  the Throwable instance representing the failure that occurred
     *
     * @param retry
     *  whether or not the job should be retried
     *
     * @return
     *  the updated AsyncJobStatus entity
     */
    private AsyncJobStatus processJobFailure(AsyncJobStatus status, EventSink eventSink, Throwable throwable,
        boolean retry) throws JobStateManagementException, JobMessageDispatchException {

        // Set the end of the execution attempt
        status.setEndTime(new Date());

        // Rollback any unsent events
        eventSink.rollback();

        // Rollback the transaction if one is still open
        EntityTransaction transaction = this.jobCurator.getTransaction();
        if (transaction != null && transaction.isActive()) {
            transaction.rollback();
        }

        String result = throwable != null ? throwable.toString() : null;

        if (retry) {
            status = this.updateJobStatus(status, JobState.FAILED_WITH_RETRY, result);

            log.warn("Job \"{}\" failed in {}ms; retrying...",
                status.getName(), this.getJobRuntime(status), throwable);

            status = this.postJobStatusMessage(status);
        }
        else {
            status = this.updateJobStatus(status, JobState.FAILED, result);

            log.error("Job \"{}\" failed in {}ms",
                status.getName(), this.getJobRuntime(status), throwable);
        }

        return status;
    }

    /**
     * Cancels the job associated with the specified job ID. If no such job status could be found,
     * this method returns null.
     *
     * @param jobId
     *  the ID of the job to cancel
     *
     * @throws IllegalStateException
     *  if the job is already in a terminal state
     *
     * @return
     *  the updated job status associated with the canceled job, or null if no such job status
     *  could be found
     */
    @Transactional
    public AsyncJobStatus cancelJob(String jobId) {
        if (jobId == null || jobId.isEmpty()) {
            throw new IllegalArgumentException("jobId is null or empty");
        }

        AsyncJobStatus status = this.jobCurator.get(jobId);
        if (status != null) {
            if (status.getState().isTerminal()) {
                throw new IllegalStateException("job is already in a terminal state: " + status);
            }

            if (status.getState() != JobState.RUNNING) {
                this.setJobState(status, JobState.CANCELED);
            }
            else {
                // Impl note: With the locking, we probably shouldn't cancel a job that's in a
                // running state, since the state change is almost guaranteed to get clobbered. For
                // now, we'll just make sure it's not set to retry if it fails; ensuring the current
                // run is the last run.
                log.warn("Attempting to cancel job that's already running: {}", status);

                if (status.getMaxAttempts() > 1) {
                    log.warn("Setting max attempts to: 1");
                    status.setMaxAttempts(1);
                }

                // TODO: Also set retry behavior to default to false here if that's added in
                // the future
            }

            status = this.jobCurator.merge(status);
        }

        return status;
    }

    /**
     * Cleans up all jobs in the given terminal states within the date range provided. If no states
     * are provided, this method defaults to all terminal states. If non-terminal states are
     * provided, they will be ignored.
     *
     * @param queryArgs
     *  an AsyncJobStatusQueryArguments instance containing the various arguments or filters to use
     *  to select jobs
     *
     * @return
     *  the number of jobs deleted as a result of this operation
     */
    @Transactional
    public int cleanupJobs(AsyncJobStatusCurator.AsyncJobStatusQueryArguments queryArgs) {
        // Prepare for the defaults...
        if (queryArgs == null) {
            queryArgs = new AsyncJobStatusQueryArguments();
        }

        // Make sure we don't attempt to blast some non-terminal jobs.
        Collection<JobState> states = queryArgs.getJobStates();
        Stream<JobState> stateStream = states != null && !states.isEmpty() ?
            states.stream() :
            Arrays.stream(JobState.values());

        states = stateStream.filter(state -> state != null && state.isTerminal())
            .collect(Collectors.toSet());

        // Only delete jobs if we haven't filtered out every state provided
        return !states.isEmpty() ? this.jobCurator.deleteJobs(queryArgs.setJobStates(states)) : 0;
    }

    /**
     * Aborts all non-terminal jobs matching the query parameters provided. If the query does not
     * specify any states, this method defaults to all non-terminal states. If any
     * terminal or running states are provided, they will be ignored.
     *
     * @param queryArgs
     *  an AsyncJobStatusQueryArguments instance containing the various arguments or filters to use
     *  to select jobs to abort
     *
     * @return
     *  the number of jobs aborted as a result of this operation
     */
    @Transactional
    public int abortNonTerminalJobs(AsyncJobStatusQueryArguments queryArgs) {
        // Prepare for the defaults...
        if (queryArgs == null) {
            queryArgs = new AsyncJobStatusQueryArguments();
        }

        // Make sure we don't attempt to abort some terminal jobs
        Collection<JobState> states = queryArgs.getJobStates();
        Stream<JobState> stateStream = states != null && !states.isEmpty() ?
            states.stream() :
            Arrays.stream(JobState.values());

        states = stateStream.filter(state -> state != null && !state.isTerminal())
            .collect(Collectors.toSet());

        // Verify that the state transition is valid for all of the queried states:
        for (JobState state : states) {
            if (!state.isValidTransition(JobState.ABORTED)) {
                throw new IllegalStateException(String.format("Cannot transition from state %s to %s",
                    state.name(), JobState.ABORTED.name()));
            }
        }

        queryArgs.setJobStates(states);

        // Add any other sanity restrictions deemed necessary here

        return this.jobCurator.updateJobState(queryArgs, JobState.ABORTED);
    }

    /**
     * @{inheritDoc}
     */
    @Override
    public void handleModeChange(CandlepinModeManager modeManager, Mode previousMode, Mode currentMode) {
        if (currentMode != null) {
            switch (currentMode) {
                case SUSPEND:
                    this.suspend(SUSPEND_KEY_TRIGGERED);
                    break;

                case NORMAL:
                    this.resume(SUSPEND_KEY_TRIGGERED);
                    break;

                default:
                    log.warn("Received an unexpected mode change notice: {}", currentMode);
            }
        }
    }

}
