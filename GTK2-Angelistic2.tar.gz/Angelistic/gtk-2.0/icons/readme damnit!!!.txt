-------------------------------------------Umicons---------------------------------------------------
Rules and regulations and all that good stuff concerning these icons:
These icons are free for personal [PERSONAL!!, I don't want any of you big companies stealing from the little guy thinking no one will notice, I don't want to be the next FOOOD(poor guy
)] use.
You can distribute them for free as long as the sets are intact and unmodified, this text file is included with every zip file in the set, and I'm given proper credit and a link to my site. 
You may not sell them or use them for profit either individually, or in any sort of collection or CD package.

Quoted from Brewman's Gorilla readme, I hope he doesn't mind. 

Big shout out to Design Technika� and SkinIt.net especially Y/C and Kol for inspiring me to do these through their using them.  

Stealing is wrong etc...



Mattahan.Web1000.com
Mattahan.deviantart.com

�Paul Davey and Mattahan Productions 2003. All Rights Reserved.

-----------------------------------------------------------------------------------------------------

Converted for Linux/KDE by norbalin
