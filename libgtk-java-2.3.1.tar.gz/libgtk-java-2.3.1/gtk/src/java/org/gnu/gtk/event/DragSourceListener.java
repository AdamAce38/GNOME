/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gtk.event;

/**
 */
public interface DragSourceListener {
	
	/**
	 * A drop has been made. We now need to supply data via the GtkSelectionData
	 */
	public void dragDataRequest( org.gnu.gtk.Widget widget, 
							org.gnu.gdk.DragContext context, 
							org.gnu.gtk.SelectionData selectionData, 
							int id, 
							int time);

}
