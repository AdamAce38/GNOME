/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gtk.event;


/**
 * An event represeting action by a {@link org.gnu.gtk.CellRendererToggle} widget.
 * @see CellRendererToggleListener
 * @see org.gnu.gtk.CellRendererToggle
 */
public class CellRendererToggleEvent extends GtkEvent {

	public static class Type extends GtkEventType{
		private Type(int id, String name){
			super(id, name);
		}

		/**
		 * This event indicates that the menu item has been toggled.
		 */
		public static final Type TOGGLED = new Type(1, "TOGGLED");
	}

	protected String index;

	/**
	 * Creates a new event. This is used internally by java-gnome. Users
	 * only have to deal with listeners.
	 */
	public CellRendererToggleEvent(Object source, String index) {
		super(source, Type.TOGGLED);
		this.index = index;
	}
	
	/**
	 * Returns the TreeIter index of which the text has been changed.
	 * @return the TreeIter index
	 */
	public String getIndex() {
		return this.index;
	}

}
