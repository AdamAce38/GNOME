/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gtk.event;

/**
 * This event represents TextBuffer events
 * 
 * @see TextBufferListener
 * @see org.gnu.gtk.TextBuffer
 */
public class TextBufferEvent extends GtkEvent {

	public static class Type extends GtkEventType {
		private Type(int id, String name) {
			super(id, name);
		}

		/**
		 */
		public static final Type APPLY_TAG = new Type(1, "APPLY_TAG");

		/**
		 */
		public static final Type CHANGED = new Type(2, "CHANGED");

		/**
		 */
		public static final Type DELETE_RANGE = new Type(3, "DELETE_RANGE");

		/**
		 */
		public static final Type INSERT_CHILD_ANCHOR = new Type(4, "INSERT_CHILD_ANCHOR");

		/**
		 */
		public static final Type INSERT_PIXBUF = new Type(5, "INSERT_PIXBUF");

		/**
		 */
		public static final Type INSERT_TEXT = new Type(6, "INSERT_TEXT");

		/**
		 */
		public static final Type MARK_DELETED = new Type(7, "MARK_DELETED");

		/**
		 */
		public static final Type MARK_SET = new Type(8, "MARK_SET");

		/**
		 */
		public static final Type MODIFIED_CHANGED = new Type(9, "MODIFIED_CHANGED");

		/**
		 */
		public static final Type REMOVE_TAG = new Type(10, "REMOVE_TAG");
	}

	public TextBufferEvent(Object source, GtkEventType type) {
		super(source, type); 
	}
		
	/**
	 * Compares to event types for equality
	 * @return true if the Types are the same
	 */
	public boolean isOfType(TextBufferEvent.Type test) {
		return type.getID() == test.getID();
	}
}
