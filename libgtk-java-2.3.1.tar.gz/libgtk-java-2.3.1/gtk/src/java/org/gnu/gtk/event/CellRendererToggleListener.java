/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gtk.event;

/**
 * Listener {@link org.gnu.gtk.CellRendererText} widgets.
 */
public interface CellRendererToggleListener {
	/**
	 * This method is called whenever the check state of the cellRenderer is changed.
	 */
	public void cellRendererToggleEvent(CellRendererToggleEvent event);

}
