/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome Team Members:
 *   Jean Van Wyk <jeanvanwyk@iname.com>
 *   Jeffrey S. Morgan <jeffrey.morgan@bristolwest.com>
 *   Dan Bornstein <danfuzz@milk.com>
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

package org.gnu.gtk.event;

import org.gnu.gdk.EventButton;
import org.gnu.gdk.EventCrossing;
import org.gnu.gdk.EventScroll;
import org.gnu.gdk.ScrollDirection;

/**
 * @author Jeffrey S. Morgan
 *
 * This event represents mouse events.
 * 
 * @see MouseListener
 */
public class MouseEvent extends GtkEvent {

	public static class Type extends GtkEventType{
		private Type(int id, String name){
			super(id, name);
		}

		/**
		 * This event indicates that the mouse has enter the widget.
		 */
		public static final Type ENTER = new Type(1, "ENTER");

		/**
		 * This event indicates that the mouse has left the widget.
		 */
		public static final Type LEAVE = new Type(2, "LEAVE");

		/**
		 * This event indicates that a mouse button has been pressed
		 */
		public static final Type BUTTON_PRESS = new Type(3, "BUTTON_PRESS");

		/**
		 * This event indicates that a mouse button has been released
		 */
		public static final Type BUTTON_RELEASE = new Type(4, "BUTTON_RELEASE");
		
		/**
		 * This event idicates that a mouse wheel was scrolled either
		 * up or down.
		 */
		public static final Type WHEEL_SCROLL = new Type(5, "WHEEL_SCROLL");
	}
		
	/**
	 * Used to identify which button was pressed.
	 */
	public static final int BUTTON1 = 4;
	public static final int BUTTON2 = 5;
	public static final int BUTTON3 = 6;

	/**
	 * Identifies what button was pressed for the BUTTON_PRESS or 
	 * BUTTON_RELEASE events.
	 */
	private int buttonPressed = -1;
	
	/**
	 * Provides the X coordinate for the BUTTON_PRESS and BUTTON_RELEASE
	 * events.
	 */
	private double x = 0;
	
	/**
	 * Provides the Y coordinate for the BUTTON_PRESS and BUTTON_RELEASE
	 * events.
	 */
	private double y = 0;
	
	/**
	 * Indicates which way the mouse wheel scrolled for a WHEEL_SCROLL event.
	 */
	private ScrollDirection direction;

	/**
	 * Construct a LifeCycleEvent object for the BUTTON event.
	 */
	public MouseEvent(Object source, Type type, EventButton gdkEvent) {
		super(source, type);
		this.x = gdkEvent.getX();
		this.y = gdkEvent.getY();
		this.buttonPressed = gdkEvent.getButton();
	}

	/**
	 * Construct a LifeCycleEvent object for the WHEEL_SCROLL event.
	 */
	public MouseEvent(Object source, Type type, EventScroll gdkEvent) {
		super(source, type);
		this.direction = gdkEvent.getScrollDirection();
	}

	/**
	 * Construct a LifeCycleEvent object for the ENTER and LEAVE event.
	 */
	public MouseEvent(Object source, Type type, EventCrossing gdkEvent) {
		super(source, type);
	}

	/**
	 * Test to compare events.
	 */
	public boolean isOfType(MouseEvent.Type test){
		return type.getID() == test.getID();
	}
	/**
	 * Returns the buttonPressed.
	 * @return int
	 */
	public int getButtonPressed() {
		return buttonPressed;
	}

	/**
	 * Returns the direction.
	 * @return ScrollDirection
	 */
	public ScrollDirection getDirection() {
		return direction;
	}

	/**
	 * Returns the x.
	 * @return double
	 */
	public double getX() {
		return x;
	}

	/**
	 * Returns the y.
	 * @return double
	 */
	public double getY() {
		return y;
	}

}
