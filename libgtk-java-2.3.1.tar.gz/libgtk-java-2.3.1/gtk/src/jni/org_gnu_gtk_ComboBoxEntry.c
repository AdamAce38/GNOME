/*
 * Java-Gnome Bindings Library
 *
 * Copyright 1998-2002 the Java-Gnome Team, all rights reserved.
 *
 * The Java-Gnome bindings library is free software distributed under
 * the terms of the GNU Library General Public License version 2.
 */

#include <jni.h>
#include <sys/types.h>
#include <gtk/gtk.h>

#ifndef _Included_org_gnu_gtk_ComboBoxEntry
#define _Included_org_gnu_gtk_ComboBoxEntry
#ifdef __cplusplus
extern "C" {
#endif
/* Inaccessible static: evtMap */
/* Inaccessible static: class_000240 */
/* Inaccessible static: class_000241 */
/* Inaccessible static: class_000242 */
/* Inaccessible static: class_000243 */
/* Inaccessible static: class_000244 */
/* Inaccessible static: class_000245 */
/* Inaccessible static: evtMap */
/* Inaccessible static: class_000240 */
/*
 * Class:     org_gnu_gtk_ComboBoxEntry
 * Method:    gtk_combo_box_entry_get_type
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_org_gnu_gtk_ComboBoxEntry_gtk_1combo_1box_1entry_1get_1type
  (JNIEnv *env, jclass cls)
{
	return (jint)gtk_combo_box_entry_get_type();
}

/*
 * Class:     org_gnu_gtk_ComboBoxEntry
 * Method:    gtk_combo_box_entry_new
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_org_gnu_gtk_ComboBoxEntry_gtk_1combo_1box_1entry_1new
  (JNIEnv *env, jclass cls)
{
	return (jint)gtk_combo_box_entry_new();
}

/*
 * Class:     org_gnu_gtk_ComboBoxEntry
 * Method:    gtk_combo_box_entry_new_with_model
 * Signature: (II)I
 */
JNIEXPORT jint JNICALL Java_org_gnu_gtk_ComboBoxEntry_gtk_1combo_1box_1entry_1new_1with_1model
  (JNIEnv *env, jclass cls, jint model, jint textColumn)
{
	return (jint)gtk_combo_box_entry_new_with_model((GtkTreeModel*)model, (gint)textColumn);
}

/*
 * Class:     org_gnu_gtk_ComboBoxEntry
 * Method:    gtk_combo_box_entry_set_text_column
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_org_gnu_gtk_ComboBoxEntry_gtk_1combo_1box_1entry_1set_1text_1column
  (JNIEnv *env, jclass cls, jint entry, jint column)
{
	gtk_combo_box_entry_set_text_column((GtkComboBoxEntry*)entry, (gint)column);
}

/*
 * Class:     org_gnu_gtk_ComboBoxEntry
 * Method:    gtk_combo_box_entry_get_text_column
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_org_gnu_gtk_ComboBoxEntry_gtk_1combo_1box_1entry_1get_1text_1column
  (JNIEnv *env, jclass cls, jint entry)
{
	return (jint)gtk_combo_box_entry_get_text_column((GtkComboBoxEntry*)entry);
}

#ifdef __cplusplus
}
#endif
#endif
