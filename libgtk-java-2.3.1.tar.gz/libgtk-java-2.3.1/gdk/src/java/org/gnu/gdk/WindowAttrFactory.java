/**
*	The Java-Gnome Team
*/


package org.gnu.gdk;

public class WindowAttrFactory{
	
	public static final WindowAttr createDefaultAttr(){
		WindowAttr attr=new WindowAttr();
		attr.setTitle("");
		attr.setPosition(10,10);
		attr.setDimension(200,200);
		return attr;
	}
}