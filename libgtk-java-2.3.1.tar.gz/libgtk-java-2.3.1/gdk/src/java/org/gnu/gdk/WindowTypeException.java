package org.gnu.gdk;


public class WindowTypeException extends IllegalArgumentException{
	
	public WindowTypeException(String message){
		super(message);
	}
}
