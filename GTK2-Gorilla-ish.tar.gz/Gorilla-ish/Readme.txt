Theme: Gorilla-ish

Author: Todd Morgan

Inspiration: Pretty-Okayish and Gorilla

Purpose: 

I wanted to create a theme like Pretty-Okayish with the same color 
scheme as the Gorilla Theme. I like Gorilla, but on my old 
machine the Industrial theme engine is rather sluggish. By using the very 
fast Pretty-Okayish theme as a template I was able to create a very fast
theme that has the same colors as Gorilla.

I hope you like it.

Disclaimer:
All credit for Pretty-Okayish and Gorilla should go towards there appropriate artists.
This Gorilla-ish theme is just a theme hack. :)
