package org.gnu.glade;

/**
 * Exception thrown due to XML parsing errors of a glade file.
 *
 * @author Tom Ball
 */
public class GladeXMLException extends java.io.IOException {

	public GladeXMLException(String s) {
		super(s);
	}

}
