package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.DateEditEvent;
import org.gnu.gnome.event.DateEditListener;

/**
 * DateEditListener delegate class.
 *
 * @author Tom Ball
 */
class DateEditDelegate extends ListenerDelegate implements DateEditListener {

	public DateEditDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void dateEditEvent(DateEditEvent event) {
		fireEvent(event);
	}
}
