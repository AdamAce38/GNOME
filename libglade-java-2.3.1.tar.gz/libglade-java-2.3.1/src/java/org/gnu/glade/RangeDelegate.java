package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.RangeEvent;
import org.gnu.gtk.event.RangeListener;

/**
 * RangeListener delegate class.
 *
 * @author Tom Ball
 */
class RangeDelegate extends ListenerDelegate implements RangeListener {

	public RangeDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void rangeEvent(RangeEvent event) {
		fireEvent(event);
	}
}
