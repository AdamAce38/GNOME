package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.AppBarEvent;
import org.gnu.gnome.event.AppBarListener;

/**
 * AppBarListener delegate class.
 *
 * @author Tom Ball
 */
class AppBarDelegate extends ListenerDelegate implements AppBarListener {

	public AppBarDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void appBarEvent(AppBarEvent event) {
		fireEvent(event);
	}
}
