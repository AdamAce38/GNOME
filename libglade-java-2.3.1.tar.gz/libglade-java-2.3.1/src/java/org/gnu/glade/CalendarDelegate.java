package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.CalendarEvent;
import org.gnu.gtk.event.CalendarListener;

/**
 * CalendarListener delegate class.
 *
 * @author Tom Ball
 */
class CalendarDelegate extends ListenerDelegate implements CalendarListener {

	public CalendarDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void calendarEvent(CalendarEvent event) {
		fireEvent(event);
	}
}
