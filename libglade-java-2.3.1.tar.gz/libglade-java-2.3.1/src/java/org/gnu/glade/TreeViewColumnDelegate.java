package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.TreeViewColumnEvent;
import org.gnu.gtk.event.TreeViewColumnListener;

/**
 * TreeViewColumnListener delegate class.
 *
 * @author Tom Ball
 */
class TreeViewColumnDelegate extends ListenerDelegate implements TreeViewColumnListener {

	public TreeViewColumnDelegate(String signal, Object owner, Method handler, Object target)
		throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void columnClickedEvent(TreeViewColumnEvent event) {
		fireEvent(event);
	}
}
