package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.ColorPickerEvent;
import org.gnu.gnome.event.ColorPickerListener;

/**
 * ColorPickerListener delegate class.
 *
 * @author Tom Ball
 */
class ColorPickerDelegate extends ListenerDelegate implements ColorPickerListener {

	public ColorPickerDelegate(String signal, Object owner, Method handler, Object target)
		throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void colorPickerEvent(ColorPickerEvent event) {
		fireEvent(event);
	}
}
