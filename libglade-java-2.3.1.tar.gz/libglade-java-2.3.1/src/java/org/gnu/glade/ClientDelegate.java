package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.ClientEvent;
import org.gnu.gnome.event.ClientListener;

/**
 * ClientListener delegate class.
 *
 * @author Tom Ball
 */
class ClientDelegate extends ListenerDelegate implements ClientListener {

	public ClientDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void clientEvent(ClientEvent event) {
		fireEvent(event);
	}
}
