package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.NotebookEvent;
import org.gnu.gtk.event.NotebookListener;

/**
 * NotebookListener delegate class.
 *
 * @author Tom Ball
 */
class NotebookDelegate extends ListenerDelegate implements NotebookListener {

	public NotebookDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void notebookEvent(NotebookEvent event) {
		fireEvent(event);
	}
}
