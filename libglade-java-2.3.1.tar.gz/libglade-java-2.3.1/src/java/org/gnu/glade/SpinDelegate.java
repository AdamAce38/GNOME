package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.SpinEvent;
import org.gnu.gtk.event.SpinListener;

/**
 * SpinListener delegate class.
 *
 * @author Tom Ball
 */
class SpinDelegate extends ListenerDelegate implements SpinListener {

	public SpinDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void spinEvent(SpinEvent event) {
		fireEvent(event);
	}
}
