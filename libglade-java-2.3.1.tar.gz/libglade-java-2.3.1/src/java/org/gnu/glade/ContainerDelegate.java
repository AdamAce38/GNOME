package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.ContainerEvent;
import org.gnu.gtk.event.ContainerListener;

/**
 * ContainerListener delegate class.
 *
 * @author Tom Ball
 */
class ContainerDelegate extends ListenerDelegate implements ContainerListener {

	public ContainerDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void containerEvent(ContainerEvent event) {
		fireEvent(event);
	}
}
