package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.AdjustmentEvent;
import org.gnu.gtk.event.AdjustmentListener;

/**
 * AdjustmentListener delegate class.
 *
 * @author Tom Ball
 */
class AdjustmentDelegate extends ListenerDelegate implements AdjustmentListener {

	public AdjustmentDelegate(String signal, Object owner, Method handler, Object target)
		throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void adjustmentEvent(AdjustmentEvent event) {
		fireEvent(event);
	}
}
