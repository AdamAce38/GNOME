package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.TextViewEvent;
import org.gnu.gtk.event.TextViewListener;

/**
 * TextViewListener delegate class.
 *
 * @author Tom Ball
 */
class TextViewDelegate extends ListenerDelegate implements TextViewListener {

	public TextViewDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void textViewEvent(TextViewEvent event) {
		fireEvent(event);
	}
}
