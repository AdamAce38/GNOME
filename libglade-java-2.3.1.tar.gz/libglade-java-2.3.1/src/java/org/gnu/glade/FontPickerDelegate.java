package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.FontPickerEvent;
import org.gnu.gnome.event.FontPickerListener;

/**
 * FontPickerListener delegate class.
 *
 * @author Tom Ball
 */
class FontPickerDelegate extends ListenerDelegate implements FontPickerListener {

	public FontPickerDelegate(String signal, Object owner, Method handler, Object target)
		throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void fontPickerEvent(FontPickerEvent event) {
		fireEvent(event);
	}
}
