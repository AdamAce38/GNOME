package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.KeyEvent;
import org.gnu.gtk.event.KeyListener;

/**
 * KeyListener delegate class.
 *
 * @author Tom Ball
 */
class KeyDelegate extends ListenerDelegate implements KeyListener {

	public KeyDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public boolean keyEvent(KeyEvent event) {
		return fireEvent(event);
	}
}
