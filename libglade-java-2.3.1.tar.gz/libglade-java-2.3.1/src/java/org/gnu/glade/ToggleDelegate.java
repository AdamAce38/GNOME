package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.ToggleEvent;
import org.gnu.gtk.event.ToggleListener;

/**
 * ToggleListener delegate class.
 *
 * @author Tom Ball
 */
class ToggleDelegate extends ListenerDelegate implements ToggleListener {

	public ToggleDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void toggleEvent(ToggleEvent event) {
		fireEvent(event);
	}
}
