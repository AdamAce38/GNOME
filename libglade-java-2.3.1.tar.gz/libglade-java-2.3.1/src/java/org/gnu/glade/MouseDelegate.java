package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.MouseEvent;
import org.gnu.gtk.event.MouseListener;

/**
 * MouseListener delegate class.
 *
 * @author Tom Ball
 */
class MouseDelegate extends ListenerDelegate implements MouseListener {

	public MouseDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public boolean mouseEvent(MouseEvent event) {
		return fireEvent(event);
	}
}
