package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.DialogEvent;
import org.gnu.gtk.event.DialogListener;

/**
 * DialogListener delegate class.
 *
 * @author Tom Ball
 */
class DialogDelegate extends ListenerDelegate implements DialogListener {

	public DialogDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public boolean dialogEvent(DialogEvent event) {
		return fireEvent(event);
	}
}
