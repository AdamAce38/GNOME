package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gnome.event.DruidPageChangeEvent;
import org.gnu.gnome.event.DruidPageChangeListener;
import org.gnu.gnome.event.DruidPageSetupEvent;
import org.gnu.gnome.event.DruidPageSetupListener;

/**
 * DruidPageListener delegate class.
 *
 * @author Tom Ball
 */
class DruidPageDelegate extends ListenerDelegate implements DruidPageChangeListener, DruidPageSetupListener {

	public DruidPageDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public boolean druidPageChangeEvent(DruidPageChangeEvent event) {
		return fireEvent(event);
	}

	public void druidPageSetupEvent(DruidPageSetupEvent event) {
		fireEvent(event);
	}

}
