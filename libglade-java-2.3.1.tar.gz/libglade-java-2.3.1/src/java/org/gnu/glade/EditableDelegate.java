package org.gnu.glade;

import java.lang.reflect.Method;

import org.gnu.gtk.event.EditableEvent;
import org.gnu.gtk.event.EditableListener;

/**
 * EditableListener delegate class.
 *
 * @author Tom Ball
 */
class EditableDelegate extends ListenerDelegate implements EditableListener {

	public EditableDelegate(String signal, Object owner, Method handler, Object target) throws NoSuchMethodException {
		super(signal, owner, handler, target);
	}

	public void editableEvent(EditableEvent event) {
		fireEvent(event);
	}
}
