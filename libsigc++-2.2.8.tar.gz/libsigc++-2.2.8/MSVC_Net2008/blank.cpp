// This file may very well be the most annoying workaround of all time.
// It is included here to simplify working with libsigc++ 2.0 using the
// MSVC IDE.
//
// This file is included in all of the MSVC projects to force the
// IDE to display the C/C++ property pages for editing.  Apparently,
// the MSVC IDE does not recognize .cc files as C++ source code, even
// though the compiler does!
//
// Tim Shead, tshead@k-3d.com
// 10/12/2004