// -*- c++ -*-
/* Do not edit! -- generated file */

#ifndef _SIGC_MACROS_HIDEHM4_
#define _SIGC_MACROS_HIDEHM4_
#endif /* _SIGC_MACROS_HIDEHM4_ */
